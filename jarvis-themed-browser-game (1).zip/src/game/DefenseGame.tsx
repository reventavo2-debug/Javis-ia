import { useCallback, useEffect, useRef, useState } from "react";

type Phase = "ready" | "playing" | "paused" | "over";

interface Threat {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  hue: number;
  spin: number;
  hit: number; // flash timer
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  hue: number;
}
interface FloatText {
  x: number;
  y: number;
  life: number;
  text: string;
  hue: number;
}

const HS_KEY = "jarvis_defense_highscores";

interface HighScore {
  score: number;
  wave: number;
  date: string;
}

function loadScores(): HighScore[] {
  try {
    return JSON.parse(localStorage.getItem(HS_KEY) || "[]");
  } catch {
    return [];
  }
}
function saveScore(s: HighScore): HighScore[] {
  const all = [...loadScores(), s].sort((a, b) => b.score - a.score).slice(0, 5);
  localStorage.setItem(HS_KEY, JSON.stringify(all));
  return all;
}

export default function DefenseGame({ onExit }: { onExit: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<Phase>("ready");
  const [score, setScore] = useState(0);
  const [hp, setHp] = useState(100);
  const [wave, setWave] = useState(1);
  const [combo, setCombo] = useState(0);
  const [scores, setScores] = useState<HighScore[]>(loadScores());
  const [isNewRecord, setIsNewRecord] = useState(false);

  // mutable game state kept in refs to avoid re-renders in the loop
  const g = useRef({
    threats: [] as Threat[],
    parts: [] as Particle[],
    floats: [] as FloatText[],
    score: 0,
    hp: 100,
    wave: 1,
    combo: 0,
    comboTimer: 0,
    spawnTimer: 0,
    spawnInterval: 1100,
    waveTimer: 0,
    shake: 0,
    coreAngle: 0,
    coreFlash: 0,
    phase: "ready" as Phase,
    w: 0,
    h: 0,
    dpr: 1,
    last: 0,
  });

  const phaseRef = useRef<Phase>("ready");
  phaseRef.current = phase;
  g.current.phase = phase;

  const spawnParticles = useCallback((x: number, y: number, hue: number, n: number, power = 1) => {
    const s = g.current;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = (Math.random() * 3 + 1) * power;
      s.parts.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: 1,
        max: Math.random() * 0.5 + 0.4,
        size: Math.random() * 3 + 1.5,
        hue,
      });
    }
  }, []);

  const resetGame = useCallback(() => {
    const s = g.current;
    s.threats = [];
    s.parts = [];
    s.floats = [];
    s.score = 0;
    s.hp = 100;
    s.wave = 1;
    s.combo = 0;
    s.comboTimer = 0;
    s.spawnTimer = 0;
    s.spawnInterval = 1100;
    s.waveTimer = 0;
    s.shake = 0;
    s.coreFlash = 0;
    setScore(0);
    setHp(100);
    setWave(1);
    setCombo(0);
    setIsNewRecord(false);
  }, []);

  const start = useCallback(() => {
    resetGame();
    setPhase("playing");
  }, [resetGame]);

  const endGame = useCallback(() => {
    const s = g.current;
    const rec: HighScore = {
      score: s.score,
      wave: s.wave,
      date: new Date().toLocaleDateString(),
    };
    const best = loadScores();
    const isRec = best.length < 5 || s.score > (best[best.length - 1]?.score ?? 0);
    if (s.score > 0) {
      setScores(saveScore(rec));
      setIsNewRecord(isRec && s.score > 0);
    }
    setPhase("over");
  }, []);
  const endGameRef = useRef(endGame);
  endGameRef.current = endGame;

  // spawn a threat from a random edge
  const spawnThreat = useCallback(() => {
    const s = g.current;
    const cx = s.w / 2;
    const cy = s.h / 2;
    const edge = Math.floor(Math.random() * 4);
    let x = 0;
    let y = 0;
    if (edge === 0) {
      x = Math.random() * s.w;
      y = -30;
    } else if (edge === 1) {
      x = s.w + 30;
      y = Math.random() * s.h;
    } else if (edge === 2) {
      x = Math.random() * s.w;
      y = s.h + 30;
    } else {
      x = -30;
      y = Math.random() * s.h;
    }
    const ang = Math.atan2(cy - y, cx - x);
    const speed = 0.55 + s.wave * 0.09 + Math.random() * 0.35;
    const tough = Math.random() < Math.min(0.15 + s.wave * 0.04, 0.5);
    const hp = tough ? 2 + Math.floor(s.wave / 3) : 1;
    s.threats.push({
      x,
      y,
      vx: Math.cos(ang) * speed,
      vy: Math.sin(ang) * speed,
      r: tough ? 26 : 18,
      hp,
      maxHp: hp,
      hue: tough ? 12 : 190,
      spin: Math.random() * Math.PI,
      hit: 0,
    });
  }, []);

  // pointer -> hit test
  const handlePointer = useCallback(
    (clientX: number, clientY: number) => {
      const s = g.current;
      if (s.phase !== "playing") return;
      const rect = canvasRef.current!.getBoundingClientRect();
      const px = clientX - rect.left;
      const py = clientY - rect.top;
      let hitOne = false;
      for (let i = s.threats.length - 1; i >= 0; i--) {
        const th = s.threats[i];
        const dx = th.x - px;
        const dy = th.y - py;
        if (dx * dx + dy * dy <= (th.r + 8) * (th.r + 8)) {
          th.hp -= 1;
          th.hit = 1;
          hitOne = true;
          spawnParticles(px, py, th.hue, 8, 1);
          s.shake = Math.min(s.shake + 3, 14);
          if (th.hp <= 0) {
            s.combo += 1;
            s.comboTimer = 2.2;
            const gain = 10 * (1 + Math.floor(s.combo / 3));
            s.score += gain;
            setScore(s.score);
            setCombo(s.combo);
            s.floats.push({ x: th.x, y: th.y, life: 1, text: `+${gain}`, hue: th.hue });
            spawnParticles(th.x, th.y, th.hue, 22, 1.6);
            s.shake = Math.min(s.shake + 6, 18);
            s.threats.splice(i, 1);
          }
          break; // one hit per tap
        }
      }
      if (!hitOne) {
        // small miss feedback
        spawnParticles(px, py, 200, 4, 0.5);
      }
    },
    [spawnParticles],
  );

  // main loop
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    const s = g.current;
    let raf = 0;

    const resize = () => {
      const rect = wrapRef.current!.getBoundingClientRect();
      s.w = rect.width;
      s.h = rect.height;
      s.dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = s.w * s.dpr;
      canvas.height = s.h * s.dpr;
      canvas.style.width = s.w + "px";
      canvas.style.height = s.h + "px";
      ctx.setTransform(s.dpr, 0, 0, s.dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const loop = (t: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min((t - (s.last || t)) / 1000, 0.05);
      s.last = t;
      const cx = s.w / 2;
      const cy = s.h / 2;

      ctx.clearRect(0, 0, s.w, s.h);

      // camera shake
      let ox = 0;
      let oy = 0;
      if (s.shake > 0.2) {
        ox = (Math.random() - 0.5) * s.shake;
        oy = (Math.random() - 0.5) * s.shake;
        s.shake *= 0.86;
      } else s.shake = 0;
      ctx.save();
      ctx.translate(ox, oy);

      s.coreAngle += dt * 0.6;
      if (s.coreFlash > 0) s.coreFlash -= dt * 2;

      const playing = s.phase === "playing";

      // ---- update ----
      if (playing) {
        // spawning
        s.spawnTimer += dt * 1000;
        if (s.spawnTimer >= s.spawnInterval) {
          s.spawnTimer = 0;
          spawnThreat();
          if (s.wave > 4 && Math.random() < 0.4) spawnThreat();
        }
        // wave up
        s.waveTimer += dt;
        if (s.waveTimer > 14) {
          s.waveTimer = 0;
          s.wave += 1;
          setWave(s.wave);
          s.spawnInterval = Math.max(420, s.spawnInterval - 120);
          s.floats.push({ x: cx, y: cy - 70, life: 1.6, text: `OLEADA ${s.wave}`, hue: 40 });
        }
        // combo decay
        if (s.comboTimer > 0) {
          s.comboTimer -= dt;
          if (s.comboTimer <= 0) {
            s.combo = 0;
            setCombo(0);
          }
        }

        // threats
        for (let i = s.threats.length - 1; i >= 0; i--) {
          const th = s.threats[i];
          th.x += th.vx * dt * 60;
          th.y += th.vy * dt * 60;
          th.spin += dt * 2;
          if (th.hit > 0) th.hit -= dt * 4;
          const dx = th.x - cx;
          const dy = th.y - cy;
          if (Math.hypot(dx, dy) < 46 + th.r) {
            // reached core
            s.hp -= th.maxHp > 1 ? 18 : 10;
            setHp(Math.max(0, s.hp));
            s.shake = 20;
            s.coreFlash = 1;
            spawnParticles(cx, cy, 12, 26, 2);
            s.combo = 0;
            setCombo(0);
            s.threats.splice(i, 1);
            if (s.hp <= 0) {
              s.hp = 0;
              endGameRef.current();
            }
          }
        }
      }

      // particles (always animate)
      for (let i = s.parts.length - 1; i >= 0; i--) {
        const p = s.parts[i];
        p.x += p.vx * dt * 60;
        p.y += p.vy * dt * 60;
        p.vx *= 0.96;
        p.vy *= 0.96;
        p.life -= dt / p.max;
        if (p.life <= 0) s.parts.splice(i, 1);
      }
      for (let i = s.floats.length - 1; i >= 0; i--) {
        const f = s.floats[i];
        f.y -= dt * 30;
        f.life -= dt;
        if (f.life <= 0) s.floats.splice(i, 1);
      }

      // ---- draw ----
      // aim lines from threats to core
      if (playing) {
        for (const th of s.threats) {
          ctx.beginPath();
          ctx.moveTo(th.x, th.y);
          ctx.lineTo(cx, cy);
          ctx.strokeStyle = `hsla(${th.hue},90%,60%,0.08)`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      // core (reactor)
      const flash = s.coreFlash > 0 ? s.coreFlash : 0;
      const coreR = 40;
      const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR + 26);
      cg.addColorStop(0, "#ffffff");
      cg.addColorStop(0.3, flash > 0 ? "#ff6a3d" : "#7cf3ff");
      cg.addColorStop(1, "rgba(10,132,255,0)");
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(cx, cy, coreR + 26, 0, Math.PI * 2);
      ctx.fill();
      // ring
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(s.coreAngle);
      ctx.strokeStyle = flash > 0 ? "rgba(255,120,80,0.9)" : "rgba(53,224,255,0.85)";
      ctx.lineWidth = 3;
      ctx.setLineDash([14, 10]);
      ctx.beginPath();
      ctx.arc(0, 0, coreR + 8, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      // threats
      for (const th of s.threats) {
        ctx.save();
        ctx.translate(th.x, th.y);
        ctx.rotate(th.spin);
        const lit = th.hit > 0 ? 85 : 58;
        ctx.strokeStyle = `hsl(${th.hue},95%,${lit}%)`;
        ctx.fillStyle = `hsla(${th.hue},90%,${lit}%,0.16)`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        const sides = th.maxHp > 1 ? 6 : 3;
        for (let k = 0; k < sides; k++) {
          const a = (k / sides) * Math.PI * 2;
          const px = Math.cos(a) * th.r;
          const py = Math.sin(a) * th.r;
          if (k === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        // inner dot
        ctx.fillStyle = `hsl(${th.hue},95%,70%)`;
        ctx.beginPath();
        ctx.arc(0, 0, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // particles
      for (const p of s.parts) {
        ctx.globalAlpha = Math.max(0, p.life);
        ctx.fillStyle = `hsl(${p.hue},95%,65%)`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // float text
      ctx.textAlign = "center";
      for (const f of s.floats) {
        ctx.globalAlpha = Math.max(0, Math.min(1, f.life));
        ctx.fillStyle = `hsl(${f.hue},95%,70%)`;
        ctx.font = f.text.startsWith("OLEADA") ? "700 30px Orbitron, sans-serif" : "700 20px Orbitron, sans-serif";
        ctx.fillText(f.text, f.x, f.y);
      }
      ctx.globalAlpha = 1;

      ctx.restore();
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [spawnThreat, spawnParticles]);

  // keyboard: P pause, Esc exit, Space start/restart
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "p" || e.key === "P") {
        setPhase((ph) => (ph === "playing" ? "paused" : ph === "paused" ? "playing" : ph));
      } else if (e.key === "Escape") {
        onExit();
      } else if (e.code === "Space") {
        e.preventDefault();
        setPhase((ph) => {
          if (ph === "ready" || ph === "over") {
            resetGame();
            return "playing";
          }
          return ph;
        });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onExit, resetGame]);

  const hpColor = hp > 50 ? "#35e0ff" : hp > 25 ? "#ffb347" : "#ff5252";

  return (
    <div ref={wrapRef} className="relative h-full w-full overflow-hidden">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 touch-none"
        onPointerDown={(e) => handlePointer(e.clientX, e.clientY)}
      />

      {/* HUD top bar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between p-3 sm:p-5">
        <div className="hud-panel hud-clip px-4 py-2">
          <div className="font-mono-tech text-[10px] tracking-widest text-cyan-300/70">PUNTUACIÓN</div>
          <div className="font-display text-2xl font-bold text-cyan-200 text-glow sm:text-3xl">
            {score.toString().padStart(5, "0")}
          </div>
        </div>

        <div className="flex flex-col items-center gap-1">
          <div className="hud-panel hud-clip px-4 py-1.5 text-center">
            <span className="font-mono-tech text-[10px] tracking-widest text-cyan-300/70">OLEADA </span>
            <span className="font-display text-lg font-bold text-amber-300 text-glow-gold">{wave}</span>
          </div>
          {combo > 1 && (
            <div key={combo} className="anim-rise font-display text-sm font-bold text-amber-300 text-glow-gold">
              COMBO x{combo}
            </div>
          )}
        </div>

        <div className="hud-panel hud-clip px-4 py-2 text-right">
          <div className="font-mono-tech text-[10px] tracking-widest text-cyan-300/70">INTEGRIDAD</div>
          <div className="mt-1 h-2 w-24 overflow-hidden rounded-full bg-cyan-950 sm:w-32">
            <div
              className="h-full rounded-full transition-all duration-200"
              style={{ width: `${hp}%`, background: hpColor, boxShadow: `0 0 10px ${hpColor}` }}
            />
          </div>
        </div>
      </div>

      {/* pause / exit buttons */}
      <div className="absolute right-3 top-20 z-30 flex gap-2 sm:right-5 sm:top-24">
        {phase === "playing" && (
          <button
            onClick={() => setPhase("paused")}
            className="btn-hud hud-clip px-3 py-1.5 font-display text-xs tracking-wider"
          >
            ❚❚ PAUSA
          </button>
        )}
        <button
          onClick={onExit}
          className="btn-hud hud-clip px-3 py-1.5 font-display text-xs tracking-wider"
        >
          ✕ SALIR
        </button>
      </div>

      {/* overlays */}
      {phase === "ready" && (
        <Overlay>
          <h2 className="font-display text-3xl font-black tracking-widest text-cyan-200 text-glow sm:text-4xl">
            PROTOCOLO DE DEFENSA
          </h2>
          <p className="max-w-md text-center text-cyan-100/70">
            Amenazas convergen sobre el reactor. <span className="text-cyan-300">Toca o haz clic</span> para
            destruirlas antes de que impacten. Encadena combos para multiplicar puntos.
          </p>
          <div className="flex flex-wrap justify-center gap-3 text-xs text-cyan-300/60">
            <span className="hud-panel hud-clip px-3 py-1">🖱️ Clic / 👆 Toque = Disparar</span>
            <span className="hud-panel hud-clip px-3 py-1">P = Pausa</span>
            <span className="hud-panel hud-clip px-3 py-1">ESC = Salir</span>
          </div>
          <button onClick={start} className="btn-hud hud-clip mt-2 px-10 py-3 font-display text-lg font-bold tracking-widest">
            ▶ INICIAR
          </button>
        </Overlay>
      )}

      {phase === "paused" && (
        <Overlay>
          <h2 className="font-display text-3xl font-black tracking-widest text-cyan-200 text-glow">EN PAUSA</h2>
          <div className="flex gap-3">
            <button onClick={() => setPhase("playing")} className="btn-hud hud-clip px-8 py-3 font-display font-bold tracking-widest">
              ▶ REANUDAR
            </button>
            <button onClick={onExit} className="btn-hud hud-clip px-8 py-3 font-display font-bold tracking-widest">
              SALIR
            </button>
          </div>
        </Overlay>
      )}

      {phase === "over" && (
        <Overlay>
          <div className="font-display text-sm tracking-[0.4em] text-red-400/80">NÚCLEO COMPROMETIDO</div>
          <h2 className="font-display text-4xl font-black tracking-widest text-red-300 text-glow">FIN DEL JUEGO</h2>
          {isNewRecord && (
            <div className="anim-flicker font-display text-lg font-bold text-amber-300 text-glow-gold">
              ★ NUEVO RÉCORD ★
            </div>
          )}
          <div className="flex gap-8">
            <div className="text-center">
              <div className="font-mono-tech text-xs tracking-widest text-cyan-300/60">PUNTUACIÓN</div>
              <div className="font-display text-3xl font-bold text-cyan-200 text-glow">{score}</div>
            </div>
            <div className="text-center">
              <div className="font-mono-tech text-xs tracking-widest text-cyan-300/60">OLEADA</div>
              <div className="font-display text-3xl font-bold text-amber-300 text-glow-gold">{wave}</div>
            </div>
          </div>

          {scores.length > 0 && (
            <div className="hud-panel hud-clip w-64 p-3">
              <div className="mb-1 text-center font-display text-xs tracking-widest text-cyan-300/70">MEJORES REGISTROS</div>
              {scores.map((sc, i) => (
                <div key={i} className="flex justify-between font-mono-tech text-sm text-cyan-100/80">
                  <span className="text-cyan-400/70">{i + 1}.</span>
                  <span>{sc.score} pts</span>
                  <span className="text-cyan-400/50">Ol.{sc.wave}</span>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-3">
            <button onClick={start} className="btn-hud hud-clip px-8 py-3 font-display font-bold tracking-widest">
              ⟳ REINTENTAR
            </button>
            <button onClick={onExit} className="btn-hud hud-clip px-8 py-3 font-display font-bold tracking-widest">
              SALIR
            </button>
          </div>
        </Overlay>
      )}
    </div>
  );
}

function Overlay({ children }: { children: React.ReactNode }) {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-5 bg-[#030711]/80 px-6 backdrop-blur-sm anim-rise">
      {children}
    </div>
  );
}
