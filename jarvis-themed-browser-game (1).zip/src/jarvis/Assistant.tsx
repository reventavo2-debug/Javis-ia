import { useCallback, useEffect, useRef, useState } from "react";
import { Coins, Mic, Send, SlidersHorizontal, Sparkles, Volume2, VolumeX } from "lucide-react";
import ArcReactor from "./ArcReactor";
import ProfilePanel from "./ProfilePanel";
import { processCommand, quickCommand, SUGGESTIONS, type JarvisReply } from "./brain";
import { streamJarvisReply, type ChatTurnFull } from "./llm";
import { useJarvisConfig } from "./config";
import { COST_PER_MESSAGE, MAX_CREDITS, useCredits } from "../hooks/useCredits";
import { useSpeech } from "../hooks/useSpeech";

interface Msg {
  id: number;
  role: "user" | "jarvis";
  text: string;
  meta?: "local" | "llm" | "error";
}

const CHAT_KEY = "jarvis_saved_chat";

function readSavedMessages(): Msg[] {
  try {
    const raw = localStorage.getItem(CHAT_KEY);
    const parsed = raw ? (JSON.parse(raw) as Msg[]) : null;
    if (parsed?.length) return parsed;
  } catch {
    /* ignore */
  }
  return [
    {
      id: 1,
      role: "jarvis",
      text: "Sistemas en línea. J.A.R.V.I.S. a su servicio. Pregúnteme lo que quiera, señor.",
      meta: "local",
    },
  ];
}

let idc = 1;

interface AssistantProps {
  onLaunchGame: () => void;
  onLaunchStudio: (mode: "image" | "video", prompt: string) => void;
}

export default function Assistant({ onLaunchGame, onLaunchStudio }: AssistantProps) {
  const [messages, setMessages] = useState<Msg[]>(() => {
    const saved = readSavedMessages();
    const maxId = saved.reduce((acc, item) => Math.max(acc, item.id), 0);
    idc = Math.max(idc, maxId + 1);
    return saved;
  });
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [streaming, setStreaming] = useState("");
  const [shake, setShake] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const logRef = useRef<HTMLDivElement>(null);
  const historyRef = useRef<ChatTurnFull[]>([]);
  const abortRef = useRef<AbortController | null>(null);
  const speakRef = useRef<(text: string) => void>(() => undefined);
  const busyRef = useRef(false);

  const { config, ready } = useJarvisConfig();
  const credits = useCredits();
  const languageRef = useRef("es-ES");

  const deliver = useCallback(
    (reply: JarvisReply, meta: Msg["meta"], userText: string) => {
      setMessages((m) => [...m, { id: idc++, role: "jarvis", text: reply.text, meta }]);
      historyRef.current = [...historyRef.current, { role: "assistant" as const, content: reply.text }].slice(-12);
      speakRef.current(reply.text);
      setShake(true);
      window.setTimeout(() => setShake(false), 420);

      if (reply.action === "clear") {
        setMessages([{ id: idc++, role: "jarvis", text: reply.text, meta }]);
        historyRef.current = [];
        return;
      }
      if (reply.action === "game") window.setTimeout(onLaunchGame, 420);
      if (reply.action === "image" || reply.action === "video") {
        const mode = reply.action;
        window.setTimeout(() => onLaunchStudio(mode, userText), 420);
      }
    },
    [onLaunchGame, onLaunchStudio],
  );

  const handleReply = useCallback(
    async (rawText: string) => {
      const userText = rawText.trim();
      if (!userText || busyRef.current) return;

      if (credits.credits < COST_PER_MESSAGE) {
        setNotice("Créditos agotados, señor. La recarga de 30 llega a las 21:00.");
        window.setTimeout(() => setNotice(""), 4000);
        return;
      }

      busyRef.current = true;
      setInput("");
      setNotice("");
      credits.spend(COST_PER_MESSAGE);
      setMessages((m) => [...m, { id: idc++, role: "user", text: userText }]);
      historyRef.current = [...historyRef.current, { role: "user" as const, content: userText }].slice(-12);
      setThinking(true);

      // Instant local intents never wait on the network.
      const quick = quickCommand(userText);
      if (quick?.action) {
        window.setTimeout(() => {
          setThinking(false);
          busyRef.current = false;
          deliver(quick, "local", userText);
        }, 200);
        return;
      }

      if (!ready) {
        window.setTimeout(() => {
          setThinking(false);
          busyRef.current = false;
          deliver(processCommand(userText), "local", userText);
        }, 170);
        return;
      }

      const controller = new AbortController();
      abortRef.current = controller;
      let last = "";
      setStreaming("");

      try {
        const finalText = await streamJarvisReply({
          prompt: userText,
          history: historyRef.current.slice(0, -1),
          apiKey: config.geminiApiKey.trim() || config.apiKey,
          model: config.geminiApiKey.trim() ? "google/gemini-3.5-flash-lite" : config.model,
          language: languageRef.current,
          onDelta: (accumulated) => {
            last = accumulated;
            setStreaming(accumulated);
          },
        });
        const text = finalText || last;
        setThinking(false);
        setStreaming("");
        speakRef.current(text);
        setMessages((m) => [...m, { id: idc++, role: "jarvis", text, meta: "llm" }]);
        historyRef.current = [...historyRef.current, { role: "assistant" as const, content: text }].slice(-12);
        setShake(true);
        window.setTimeout(() => setShake(false), 420);
      } catch (error) {
        setThinking(false);
        setStreaming("");
        if ((error as Error).name === "AbortError") return;
        setNotice(`${(error as Error).message} Respondo con el núcleo local.`);
        window.setTimeout(() => setNotice(""), 6000);
        deliver(processCommand(userText), "error", userText);
      } finally {
        abortRef.current = null;
        busyRef.current = false;
      }
    },
    [config.apiKey, config.model, credits, deliver, ready],
  );

  const speech = useSpeech((text) => {
    void handleReply(text);
  });
  speakRef.current = speech.speak;
  languageRef.current = speech.selectedLanguage;

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, streaming, thinking]);

  useEffect(() => {
    localStorage.setItem(CHAT_KEY, JSON.stringify(messages));
    historyRef.current = messages
      .filter((m) => m.role === "user" || m.role === "jarvis")
      .map((m) => ({ role: m.role === "jarvis" ? ("assistant" as const) : ("user" as const), content: m.text }))
      .slice(-12);
  }, [messages]);

  useEffect(() => {
    if (speech.interimTranscript) setInput(speech.interimTranscript);
  }, [speech.interimTranscript]);

  useEffect(() => {
    const stopNarration = () => speech.stopSpeaking();
    window.addEventListener("pointerdown", stopNarration);
    return () => {
      window.removeEventListener("pointerdown", stopNarration);
      abortRef.current?.abort();
      busyRef.current = false;
    };
  }, [speech]);

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    void handleReply(input);
  };

  const reactorState = speech.listening ? "listening" : speech.speaking ? "speaking" : thinking ? "thinking" : "idle";
  const percent = Math.round((credits.credits / MAX_CREDITS) * 100);
  const outOfCredits = credits.credits < COST_PER_MESSAGE;

  return (
    <div className={`relative z-10 mx-auto flex h-full w-full max-w-6xl flex-col px-3 py-3 sm:px-4 sm:py-5 ${shake ? "shake" : ""}`}>
      <header className="mb-2 flex shrink-0 items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-3">
          <ArcReactor size={50} state={reactorState} />
          <div className="min-w-0">
            <h1 className="font-display text-lg font-black tracking-[0.3em] text-cyan-200 text-glow sm:text-2xl">J.A.R.V.I.S.</h1>
            <p className="truncate font-mono-tech text-[9px] tracking-[0.18em] text-cyan-400/60 sm:text-[10px]">
              {speech.listening
                ? "ESCUCHANDO…"
                : speech.speaking
                  ? "TRANSMITIENDO…"
                  : thinking
                    ? "PENSANDO…"
                    : ready
                      ? "IA AVANZADA EN LÍNEA"
                      : "MOTOR LOCAL · SIN CLAVE DE IA"}
            </p>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1.5">
          <button
            onClick={() => setProfileOpen(true)}
            className="group flex items-center gap-2 border border-cyan-400/25 bg-[#04101f]/75 px-2.5 py-1.5 transition hover:border-cyan-300/60 hover:bg-cyan-400/10"
            title="Créditos y configuración"
          >
            <Coins size={13} className="text-amber-300 transition group-hover:scale-110" />
            <span className="font-display text-sm font-black tabular-nums text-cyan-100">{credits.credits}</span>
            <span className="hidden h-1.5 w-10 overflow-hidden rounded-full bg-cyan-950 sm:block">
              <span
                className="block h-full rounded-full transition-all duration-500"
                style={{
                  width: `${percent}%`,
                  background: percent > 40 ? "#35e0ff" : percent > 15 ? "#ffb347" : "#ff5252",
                  boxShadow: "0 0 8px currentColor",
                }}
              />
            </span>
            {credits.bonusJustAdded > 0 && (
              <span className="anim-rise font-mono-tech text-[9px] font-bold text-emerald-300">+{credits.bonusJustAdded}</span>
            )}
          </button>

          <button
            onClick={() => onLaunchStudio("image", "")}
            className="btn-hud hud-clip hidden items-center gap-1.5 px-3 py-2 font-mono-tech text-[11px] tracking-wider sm:flex"
            title="Abrir JARVIS Studio"
          >
            <Sparkles size={13} /> CREAR
          </button>
          <button
            onClick={speech.toggleVoice}
            className="btn-hud hud-clip grid h-9 w-9 place-items-center"
            title={speech.voiceEnabled ? "Silenciar voz" : "Activar voz"}
          >
            {speech.voiceEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
          </button>
          <button
            onClick={() => setProfileOpen(true)}
            className="btn-hud hud-clip grid h-9 w-9 place-items-center"
            title="Perfil"
          >
            <SlidersHorizontal size={15} />
          </button>
        </div>
      </header>

      <div className="mb-3 flex shrink-0 items-center justify-center">
        <ArcReactor size={typeof window !== "undefined" && window.innerWidth < 640 ? 154 : 196} state={reactorState} />
      </div>

      {!ready && (
        <button
          onClick={() => setProfileOpen(true)}
          className="mb-2 flex shrink-0 items-center justify-between gap-3 border border-amber-300/30 bg-amber-400/8 px-3 py-2 text-left transition hover:border-amber-200/60 hover:bg-amber-400/14"
        >
          <span className="text-[11px] leading-snug text-amber-100/80">
            Respondo con el núcleo local, señor. Añada una clave en <strong>Perfil → Inteligencia</strong> para pensar de verdad.
          </span>
          <span className="shrink-0 font-display text-[10px] font-bold tracking-widest text-amber-200">CONECTAR</span>
        </button>
      )}

      <div ref={logRef} className="jv-scroll hud-panel hud-clip mb-2 min-h-0 flex-1 space-y-3 overflow-y-auto p-3 sm:p-4">
        {messages.map((m) => (
          <div key={m.id} className={`anim-rise flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[88%] rounded-sm px-3 py-2 text-sm leading-relaxed sm:text-[15px] ${
                m.role === "user"
                  ? "border border-cyan-400/30 bg-cyan-500/14 text-cyan-100"
                  : "border border-cyan-300/15 border-l-2 border-l-cyan-300/70 bg-blue-950/40 text-cyan-50"
              }`}
            >
              {m.role === "jarvis" && (
                <div className="mb-1 flex items-center gap-2">
                  <span className="font-display text-[9px] tracking-[0.25em] text-cyan-400/70">JARVIS</span>
                  {m.meta === "llm" && <span className="font-mono-tech text-[8px] tracking-widest text-emerald-300/70">IA</span>}
                  {m.meta === "local" && <span className="font-mono-tech text-[8px] tracking-widest text-cyan-300/45">LOCAL</span>}
                  {m.meta === "error" && <span className="font-mono-tech text-[8px] tracking-widest text-amber-300/70">DEGRADADO</span>}
                </div>
              )}
              {m.text}
            </div>
          </div>
        ))}

        {thinking && !streaming && (
          <div className="flex justify-start">
            <div className="flex items-center gap-3 border border-cyan-300/20 bg-blue-950/40 px-4 py-3">
              <span className="inline-flex gap-1">
                <Dot delay={0} />
                <Dot delay={0.15} />
                <Dot delay={0.3} />
              </span>
              <span className="font-mono-tech text-[9px] tracking-widest text-cyan-300/50">
                {ready ? "CONSULTANDO MODELO…" : "PROCESANDO…"}
              </span>
            </div>
          </div>
        )}

        {streaming && (
          <div className="flex justify-start">
            <div className="max-w-[88%] border border-cyan-300/15 border-l-2 border-l-cyan-300 bg-blue-950/50 px-3 py-2 text-sm leading-relaxed text-cyan-50">
              {streaming}
              <span className="ml-0.5 inline-block h-4 w-[7px] translate-y-0.5 animate-pulse bg-cyan-300" />
            </div>
          </div>
        )}
      </div>

      <div className="jv-scroll mb-2 flex shrink-0 gap-2 overflow-x-auto pb-1">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => void handleReply(s)}
            disabled={thinking || outOfCredits}
            className="shrink-0 rounded-full border border-cyan-400/22 bg-cyan-500/5 px-3 py-1 text-xs text-cyan-200/80 transition hover:border-cyan-300/60 hover:bg-cyan-500/15 disabled:opacity-35"
          >
            {s}
          </button>
        ))}
      </div>

      {notice && (
        <div className="mb-2 shrink-0 border border-amber-300/35 bg-amber-400/10 px-3 py-2 text-xs text-amber-100 anim-rise">{notice}</div>
      )}

      <form onSubmit={submit} className="relative flex shrink-0 items-center gap-2">
        {speech.listening && speech.continuousConversation && (
          <div className="absolute -top-4 left-2 flex items-center gap-1.5 font-mono-tech text-[9px] tracking-widest text-cyan-300/70">
            <span className="h-1.5 w-1.5 rounded-full bg-red-400 shadow-[0_0_8px_#f87171]" />
            ESCUCHA CONTINUA ACTIVA
          </div>
        )}
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={outOfCredits}
          placeholder={outOfCredits ? "Créditos agotados — recarga a las 21:00" : "Hable o escriba un comando para JARVIS…"}
          className="hud-panel hud-clip min-w-0 flex-1 bg-transparent px-4 py-3 text-cyan-100 placeholder-cyan-400/40 outline-none focus:border-cyan-400/60 disabled:opacity-50"
        />
        {speech.supported && (
          <button
            type="button"
            onClick={speech.listening ? speech.stopListening : speech.startListening}
            className={`hud-clip grid h-12 w-12 shrink-0 place-items-center border transition ${
              speech.listening
                ? "anim-flicker border-red-400/60 bg-red-500/20 text-red-200"
                : "border-cyan-400/40 bg-cyan-500/10 text-cyan-200 hover:bg-cyan-500/20"
            }`}
            title={speech.listening ? "Dejar de escuchar" : "Escuchar por voz"}
          >
            <Mic size={18} />
          </button>
        )}
        <button
          type="submit"
          disabled={thinking || outOfCredits}
          className="btn-hud hud-clip grid h-12 w-12 shrink-0 place-items-center disabled:opacity-40"
          title="Enviar"
        >
          <Send size={17} />
        </button>
      </form>

      {profileOpen && <ProfilePanel speech={speech} credits={credits} onClose={() => setProfileOpen(false)} />}
    </div>
  );
}

function Dot({ delay }: { delay: number }) {
  return (
    <span
      className="inline-block h-2 w-2 rounded-full bg-cyan-300"
      style={{ animation: `pulse-core 1s ease-in-out ${delay}s infinite` }}
    />
  );
}
