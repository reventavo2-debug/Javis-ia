export interface ChatTurn {
  role: "user" | "assistant";
}

export interface ChatTurnFull extends ChatTurn {
  content: string;
}

const ENDPOINT = "https://gen.pollinations.ai/v1/chat/completions";
const TIMEOUT_MS = 45_000;

const LANGUAGE_NAMES: Record<string, string> = {
  es: "Español (responda SIEMPRE en español, trate al usuario de «señor»)",
  en: "English (always answer in English, address the user as «sir»)",
  de: "Deutsch (antworten Sie immer auf Deutsch, Anrede »mein Herr«)",
  ru: "Русский (всегда отвечайте по-русски, обращение «сэр»)",
  zh: "简体中文 (始终用中文回答，称呼用户为“先生”)",
  it: "Italiano (risponda sempre in italiano, si rivolga all'utente come «signore»)",
  fr: "Français (répondez toujours en français, interpellez l'utilisateur « monsieur »)",
};

function systemPrompt(language: string) {
  const base = language.toLowerCase().split("-")[0];
  const now = new Date();
  const stamp = now.toLocaleString(base === "es" ? "es-ES" : base, {
    dateStyle: "full",
    timeStyle: "short",
  });
  return [
    "Eres J.A.R.V.I.S., la inteligencia artificial del traje de Iron Man, integrada en una interfaz HUD.",
    LANGUAGE_NAMES[base] ?? LANGUAGE_NAMES.es,
    "Personalidad: brillante, preciso, cortés, con humor británico seco y sutil. Nunca rompes el personaje.",
    `Fecha y hora actuales del dispositivo del usuario: ${stamp}.`,
    "Capacidades reales de esta app: chat por voz y texto con micrófono continuo, un minijuego llamado Protocolo de Defensa, y un JARVIS Studio que crea imágenes 4K y vídeos. Si te piden crear una imagen o un vídeo, responde en una frase y anima a usar el botón CREAR.",
    "Formato de salida: texto plano, 1 a 4 frases salvo que pidan detalle. Nada de markdown, ni listas con viñetas, ni emojis, ni comillas envolventes.",
    "Si no sabes un dato, dilo con elegancia en lugar de inventarlo. Sé útil y concreto, nunca genérico.",
  ].join("\n");
}

export interface StreamOptions {
  prompt: string;
  history: ChatTurnFull[];
  apiKey: string;
  model: string;
  language: string;
  onDelta: (accumulated: string) => void;
}

export class LlmError extends Error {}

export async function streamJarvisReply({
  prompt,
  history,
  apiKey,
  model,
  language,
  onDelta,
}: StreamOptions): Promise<string> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), TIMEOUT_MS);

  const messages = [
    { role: "system", content: systemPrompt(language) },
    ...history.slice(-10),
    { role: "user", content: prompt },
  ];

  try {
    const response = await fetch(ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey.trim()}`,
      },
      body: JSON.stringify({ model, messages, stream: true }),
      signal: controller.signal,
    });

    if (!response.ok) {
      let detail = "";
      try {
        const payload = await response.json();
        detail = payload?.error?.message || payload?.message || "";
      } catch {
        detail = await response.text().catch(() => "");
      }
      if (response.status === 401 || response.status === 403) {
        throw new LlmError("Clave no válida o sin permisos para este modelo.");
      }
      if (response.status === 402) throw new LlmError("Sin saldo en la cuenta del proveedor.");
      if (response.status === 429) throw new LlmError("Límite de peticiones alcanzado. Espere unos segundos.");
      throw new LlmError(detail || `El proveedor respondió ${response.status}.`);
    }

    if (!response.body) {
      const data = await response.json();
      const text: string = data?.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) throw new LlmError("El modelo devolvió una respuesta vacía.");
      onDelta(text);
      return text;
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let accumulated = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";

      for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const parsed = JSON.parse(payload);
          const delta: string = parsed?.choices?.[0]?.delta?.content ?? "";
          if (delta) {
            accumulated += delta;
            onDelta(accumulated);
          }
        } catch {
          // Ignore keep-alive or partial frames.
        }
      }
    }

    const clean = accumulated.trim();
    if (!clean) throw new LlmError("El modelo no devolvió texto utilizable.");
    return clean;
  } catch (error) {
    if ((error as Error).name === "AbortError") {
      throw new LlmError("El modelo ha tardado demasiado en responder.");
    }
    if (error instanceof LlmError) throw error;
    throw new LlmError("No se pudo contactar con el proveedor de IA. Compruebe la conexión o la clave.");
  } finally {
    window.clearTimeout(timeout);
  }
}
