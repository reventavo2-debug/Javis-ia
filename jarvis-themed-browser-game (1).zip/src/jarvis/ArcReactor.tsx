interface Props {
  size?: number;
  state: "idle" | "listening" | "speaking" | "thinking";
}

export default function ArcReactor({ size = 220, state }: Props) {
  const active = state !== "idle";
  const color =
    state === "listening" ? "#35e0ff" : state === "speaking" ? "#7cf3ff" : state === "thinking" ? "#ffb347" : "#35e0ff";

  return (
    <div
      className="relative anim-pulse-core"
      style={{ width: size, height: size }}
      aria-label="Reactor Arc"
    >
      <svg viewBox="0 0 200 200" width={size} height={size}>
        <defs>
          <radialGradient id="core-grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="35%" stopColor={color} />
            <stop offset="100%" stopColor="#0a84ff" stopOpacity="0.1" />
          </radialGradient>
        </defs>

        {/* outer rotating ring */}
        <g className="anim-spin-slow" style={{ transformOrigin: "100px 100px" }}>
          <circle cx="100" cy="100" r="92" fill="none" stroke={color} strokeOpacity="0.35" strokeWidth="1" strokeDasharray="4 10" />
          {Array.from({ length: 24 }).map((_, i) => {
            const a = (i / 24) * Math.PI * 2;
            const x1 = 100 + Math.cos(a) * 80;
            const y1 = 100 + Math.sin(a) * 80;
            const x2 = 100 + Math.cos(a) * 88;
            const y2 = 100 + Math.sin(a) * 88;
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeOpacity="0.6" strokeWidth="2" />;
          })}
        </g>

        {/* mid counter-rotating ring */}
        <g className="anim-spin-rev" style={{ transformOrigin: "100px 100px" }}>
          <circle cx="100" cy="100" r="66" fill="none" stroke={color} strokeOpacity="0.5" strokeWidth="2" strokeDasharray="30 14" />
        </g>

        {/* triangular coil ring (classic arc reactor) */}
        <g className={active ? "anim-spin-fast" : "anim-spin-slow"} style={{ transformOrigin: "100px 100px" }}>
          {Array.from({ length: 9 }).map((_, i) => {
            const a = (i / 9) * Math.PI * 2;
            const x = 100 + Math.cos(a) * 46;
            const y = 100 + Math.sin(a) * 46;
            return (
              <g key={i} transform={`translate(${x} ${y}) rotate(${(a * 180) / Math.PI + 90})`}>
                <path d="M0 -9 L7 6 L-7 6 Z" fill="none" stroke={color} strokeOpacity="0.8" strokeWidth="1.6" />
              </g>
            );
          })}
          <circle cx="100" cy="100" r="46" fill="none" stroke={color} strokeOpacity="0.4" strokeWidth="1" />
        </g>

        {/* core */}
        <circle cx="100" cy="100" r="30" fill="url(#core-grad)" />
        <circle cx="100" cy="100" r="18" fill="#eafcff" opacity="0.95" />
        <circle cx="100" cy="100" r="9" fill="#ffffff" />
      </svg>
    </div>
  );
}
