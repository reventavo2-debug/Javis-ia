import { useEffect, useState } from "react";
import {
  BadgeCheck,
  BrainCircuit,
  Coins,
  Eye,
  EyeOff,
  Gauge,
  KeyRound,
  Languages,
  Loader2,
  Mic,
  RefreshCw,
  Sparkles,
  Volume2,
  VolumeX,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import { MODELS, useJarvisConfig } from "./config";
import { COST_PER_MESSAGE, DAILY_BONUS, MAX_CREDITS, type CreditsApi } from "../hooks/useCredits";
import type { useSpeech } from "../hooks/useSpeech";

type SpeechApi = ReturnType<typeof useSpeech>;
type Tab = "ai" | "voice" | "credits";

interface Props {
  speech: SpeechApi;
  credits: CreditsApi;
  onClose: () => void;
}

function formatCountdown(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function Countdown({ target }: { target: number }) {
  const [remaining, setRemaining] = useState(() => target - Date.now());
  useEffect(() => {
    setRemaining(target - Date.now());
    const timer = window.setInterval(() => setRemaining(target - Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [target]);
  return <span className="tabular-nums">{formatCountdown(remaining)}</span>;
}

export default function ProfilePanel({ speech, credits, onClose }: Props) {
  const { config, update, ready } = useJarvisConfig();
  const [tab, setTab] = useState<Tab>("ai");
  const [revealed, setRevealed] = useState(false);
  const [revealedGemini, setRevealedGemini] = useState(false);
  const [draftKey, setDraftKey] = useState(config.apiKey);
  const [draftGeminiKey, setDraftGeminiKey] = useState(config.geminiApiKey);
  const [checking, setChecking] = useState(false);
  const [checkResult, setCheckResult] = useState<{ ok: boolean; message: string } | null>(null);

  useEffect(() => {
    setDraftKey(config.apiKey);
    setDraftGeminiKey(config.geminiApiKey);
  }, [config.apiKey, config.geminiApiKey]);

  // The "+30" badge expires on its own (handled inside the credits hook).

  const saveKey = () => {
    update({ apiKey: draftKey.trim(), geminiApiKey: draftGeminiKey.trim() });
    setCheckResult(null);
  };

  const verify = async () => {
    const key = draftKey.trim() || config.apiKey;
    if (!key) {
      setCheckResult({ ok: false, message: "Introduzca una clave para comprobarla." });
      return;
    }
    setChecking(true);
    setCheckResult(null);
    try {
      const response = await fetch("https://gen.pollinations.ai/v1/models", {
        headers: { Authorization: `Bearer ${key}` },
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      const count = Array.isArray(data?.data) ? data.data.length : Array.isArray(data) ? data.length : 0;
      update({ apiKey: key });
      setCheckResult({ ok: true, message: `Conexión establecida. ${count || "Varios"} modelos disponibles.` });
    } catch (error) {
      setCheckResult({
        ok: false,
        message: error instanceof Error ? `No se pudo contactar con el proveedor (${error.message}).` : "Error de red.",
      });
    } finally {
      setChecking(false);
    }
  };

  const activeModel = MODELS.find((model) => model.id === config.model) ?? MODELS[0];
  const percent = Math.round((credits.credits / MAX_CREDITS) * 100);
  const selectedVoice = speech.voiceOptions.find((voice) => voice.id === speech.selectedVoiceId);

  const tabs: { id: Tab; label: string; icon: typeof BrainCircuit }[] = [
    { id: "ai", label: "INTELIGENCIA", icon: BrainCircuit },
    { id: "voice", label: "VOZ E IDIOMA", icon: Languages },
    { id: "credits", label: "CRÉDITOS", icon: Coins },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-stretch justify-center bg-[#01050d]/85 p-0 backdrop-blur-md sm:items-center sm:p-6">
      <div
        className="hud-panel flex h-full w-full max-w-5xl flex-col overflow-hidden border-cyan-400/25 anim-rise sm:h-auto sm:max-h-[88vh]"
        style={{ boxShadow: "0 0 60px rgba(10,132,255,0.16), inset 0 0 40px rgba(53,224,255,0.05)" }}
      >
        {/* header */}
        <div className="flex shrink-0 items-center justify-between border-b border-cyan-400/15 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center border border-cyan-400/35 bg-cyan-400/10 text-cyan-200">
              <Gauge size={17} />
            </span>
            <div>
              <div className="font-display text-sm font-black tracking-[0.3em] text-cyan-100 text-glow sm:text-base">
                PERFIL DE SISTEMA
              </div>
              <div className="font-mono-tech text-[9px] tracking-[0.22em] text-cyan-400/50">
                {ready ? "NÚCLEO IA CONECTADO" : "MODO LOCAL · AÑADA UNA CLAVE PARA IA AVANZADA"}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="btn-hud hud-clip grid h-9 w-9 place-items-center text-cyan-200"
            aria-label="Cerrar perfil"
          >
            <X size={16} />
          </button>
        </div>

        <div className="flex min-h-0 flex-1 flex-col md:flex-row">
          {/* rail */}
          <nav className="flex shrink-0 gap-1 border-b border-cyan-400/12 px-3 py-2 md:w-52 md:flex-col md:border-b-0 md:border-r md:px-3 md:py-4">
            {tabs.map((item) => {
              const Icon = item.icon;
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setTab(item.id)}
                  className={`group relative flex flex-1 items-center gap-2.5 px-3 py-2.5 text-left transition md:flex-none ${
                    active ? "bg-cyan-400/12 text-cyan-100" : "text-cyan-300/50 hover:bg-cyan-400/6 hover:text-cyan-200"
                  }`}
                >
                  <span
                    className={`absolute inset-y-0 left-0 w-[2px] transition-all ${active ? "bg-cyan-300 shadow-[0_0_10px_#35e0ff]" : "bg-transparent"}`}
                  />
                  <Icon size={15} className={active ? "text-cyan-200" : "text-cyan-400/50"} />
                  <span className="font-mono-tech text-[10px] tracking-[0.16em]">{item.label}</span>
                </button>
              );
            })}

            <div className="mt-auto hidden border border-cyan-400/15 bg-[#04101f]/70 p-3 md:block">
              <div className="font-mono-tech text-[9px] tracking-widest text-cyan-400/50">CRÉDITOS ACTIVOS</div>
              <div className="font-display text-3xl font-black text-cyan-100 text-glow">{credits.credits}</div>
              <div className="mt-2 h-1 w-full overflow-hidden bg-cyan-950">
                <div
                  className="h-full transition-all duration-500"
                  style={{
                    width: `${percent}%`,
                    background: percent > 40 ? "#35e0ff" : percent > 15 ? "#ffb347" : "#ff5252",
                    boxShadow: "0 0 10px currentColor",
                  }}
                />
              </div>
            </div>
          </nav>

          {/* content */}
          <div className="jv-scroll min-h-0 flex-1 overflow-y-auto px-4 py-4 sm:px-6 sm:py-5">
            {tab === "ai" && (
              <div className="space-y-5 anim-rise">
                <div className="grid gap-4 lg:grid-cols-[1.15fr_1fr]">
                  <section>
                    <label htmlFor="jarvis-api-key" className="flex items-center gap-2 font-display text-[10px] tracking-[0.2em] text-cyan-200">
                      <KeyRound size={12} /> CLAVE DE LA API
                    </label>
                      <p className="mt-1 text-xs leading-relaxed text-cyan-100/50">
                        Con una clave compatible con OpenAI, JARVIS piensa de verdad: entiende cualquier pregunta, recuerda el
                        contexto de la conversación y responde al instante. La clave se guarda en este navegador hasta que usted
                        la cambie o la quite.
                      </p>
                    <div className="mt-2 flex items-stretch gap-1">
                      <input
                        id="jarvis-api-key"
                        type={revealed ? "text" : "password"}
                        value={draftKey}
                        onChange={(event) => setDraftKey(event.target.value)}
                        placeholder="clave OpenAI/Pollinations compatible"
                        autoComplete="off"
                        spellCheck={false}
                        className="min-w-0 flex-1 border border-cyan-400/25 bg-[#050f1d] px-3 py-2.5 font-mono-tech text-xs text-cyan-50 outline-none placeholder:text-cyan-300/25 focus:border-cyan-300"
                      />
                      <button
                        onClick={() => setRevealed((value) => !value)}
                        className="grid w-10 place-items-center border border-cyan-400/20 text-cyan-300/70 transition hover:border-cyan-300/60 hover:text-cyan-100"
                        aria-label={revealed ? "Ocultar clave" : "Mostrar clave"}
                      >
                        {revealed ? <EyeOff size={15} /> : <Eye size={15} />}
                      </button>
                    </div>

                    <label htmlFor="jarvis-gemini-key" className="mt-3 flex items-center gap-2 font-display text-[10px] tracking-[0.2em] text-cyan-200">
                      <Sparkles size={12} /> CLAVE DE GEMINI
                    </label>
                    <div className="mt-2 flex items-stretch gap-1">
                      <input
                        id="jarvis-gemini-key"
                        type={revealedGemini ? "text" : "password"}
                        value={draftGeminiKey}
                        onChange={(event) => setDraftGeminiKey(event.target.value)}
                        placeholder="pega tu clave de Gemini aquí"
                        autoComplete="off"
                        spellCheck={false}
                        className="min-w-0 flex-1 border border-cyan-400/25 bg-[#050f1d] px-3 py-2.5 font-mono-tech text-xs text-cyan-50 outline-none placeholder:text-cyan-300/25 focus:border-cyan-300"
                      />
                      <button
                        onClick={() => setRevealedGemini((value) => !value)}
                        className="grid w-10 place-items-center border border-cyan-400/20 text-cyan-300/70 transition hover:border-cyan-300/60 hover:text-cyan-100"
                        aria-label={revealedGemini ? "Ocultar clave Gemini" : "Mostrar clave Gemini"}
                      >
                        {revealedGemini ? <EyeOff size={15} /> : <Eye size={15} />}
                      </button>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <button onClick={saveKey} className="btn-hud hud-clip px-4 py-2 font-display text-[10px] font-bold tracking-widest">
                        GUARDAR
                      </button>
                      <button
                        onClick={verify}
                        disabled={checking}
                        className="btn-hud hud-clip flex items-center gap-2 px-4 py-2 font-display text-[10px] font-bold tracking-widest disabled:opacity-50"
                      >
                        {checking ? <Loader2 size={12} className="animate-spin" /> : <Wifi size={12} />}
                        {checking ? "COMPROBANDO" : "PROBAR CONEXIÓN"}
                      </button>
                      <button
                        onClick={() => {
                          setDraftKey("");
                          setDraftGeminiKey("");
                          update({ apiKey: "", geminiApiKey: "" });
                          setCheckResult(null);
                        }}
                        className="border border-cyan-400/15 px-4 py-2 font-mono-tech text-[10px] tracking-widest text-cyan-300/50 transition hover:border-red-400/40 hover:text-red-200"
                      >
                        QUITAR
                      </button>
                    </div>

                    {checkResult && (
                      <div
                        className={`mt-3 flex items-start gap-2 border p-3 text-xs leading-relaxed anim-rise ${
                          checkResult.ok
                            ? "border-emerald-400/35 bg-emerald-400/8 text-emerald-100"
                            : "border-red-400/35 bg-red-500/8 text-red-100"
                        }`}
                      >
                        {checkResult.ok ? <BadgeCheck size={14} className="mt-0.5 shrink-0" /> : <X size={14} className="mt-0.5 shrink-0" />}
                        {checkResult.message}
                      </div>
                    )}
                  </section>

                  <section className="border border-cyan-400/15 bg-[#04101f]/60 p-4">
                    <div className="font-mono-tech text-[9px] tracking-widest text-cyan-400/50">ESTADO DEL NÚCLEO</div>
                    <div className="mt-2 flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${ready ? "bg-emerald-400" : "bg-amber-400"} shadow-[0_0_10px_currentColor]`} />
                      <span className="font-display text-sm font-bold tracking-wider text-cyan-100">
                        {ready ? "IA AVANZADA ACTIVA" : "MOTOR LOCAL"}
                      </span>
                    </div>
                    <dl className="mt-3 space-y-1.5 font-mono-tech text-[10px] tracking-wider">
                      <div className="flex justify-between gap-3">
                        <dt className="text-cyan-400/50">MODELO</dt>
                        <dd className="truncate text-cyan-100/85">{ready ? activeModel.id : "reglas locales"}</dd>
                      </div>
                      <div className="flex justify-between gap-3">
                        <dt className="text-cyan-400/50">GEMINI</dt>
                        <dd className="truncate text-cyan-100/85">{config.geminiApiKey.trim() ? "conectada" : "sin clave"}</dd>
                      </div>
                      <div className="flex justify-between gap-3">
                        <dt className="text-cyan-400/50">MEMORIA</dt>
                        <dd className="text-cyan-100/85">10 turnos</dd>
                      </div>
                      <div className="flex justify-between gap-3">
                        <dt className="text-cyan-400/50">ENTRADA</dt>
                        <dd className="text-cyan-100/85">{COST_PER_MESSAGE} crédito</dd>
                      </div>
                    </dl>

                    <button
                      onClick={() => update({ useLlm: !config.useLlm })}
                      className="mt-4 flex w-full items-center justify-between border border-cyan-400/20 px-3 py-2 text-left transition hover:border-cyan-300/50"
                    >
                      <span>
                        <span className="block font-display text-[10px] tracking-widest text-cyan-100">USAR IA REMOTA</span>
                        <span className="block text-[10px] text-cyan-300/45">Desactívelo para respuestas solo locales</span>
                      </span>
                      <span className={`relative h-5 w-9 shrink-0 rounded-full transition ${config.useLlm ? "bg-cyan-400/70" : "bg-slate-700"}`}>
                        <span
                          className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${config.useLlm ? "left-[18px]" : "left-0.5"}`}
                        />
                      </span>
                    </button>
                    <a
                      href="https://enter.pollinations.ai/keys"
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 flex items-center gap-1.5 font-mono-tech text-[10px] tracking-wider text-cyan-300/60 transition hover:text-cyan-200"
                    >
                      <Sparkles size={11} /> OBTENER UNA CLAVE DEL PROVEEDOR
                    </a>
                  </section>
                </div>

                <section>
                  <div className="mb-2 flex items-center gap-2 font-display text-[10px] tracking-[0.2em] text-cyan-200">
                    <Zap size={12} /> MOTOR DE RAZONAMIENTO
                  </div>
                  <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                    {MODELS.map((model) => {
                      const active = config.model === model.id;
                      return (
                        <button
                          key={model.id}
                          onClick={() => update({ model: model.id })}
                          className={`group border p-3 text-left transition-all duration-200 ${
                            active
                              ? "border-cyan-300/70 bg-cyan-400/12 shadow-[0_0_18px_rgba(53,224,255,0.18)]"
                              : "border-cyan-400/18 bg-[#04101f]/50 hover:-translate-y-0.5 hover:border-cyan-300/45"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono-tech text-[9px] tracking-widest text-cyan-400/60">{model.tier}</span>
                            {active && <BadgeCheck size={13} className="text-cyan-200" />}
                          </div>
                          <div className={`mt-1 font-display text-xs font-bold tracking-wide ${active ? "text-cyan-100" : "text-cyan-100/75"}`}>
                            {model.label}
                          </div>
                          <div className="mt-0.5 truncate font-mono-tech text-[9px] text-cyan-300/40">{model.id}</div>
                        </button>
                      );
                    })}
                  </div>
                </section>
              </div>
            )}

            {tab === "voice" && (
              <div className="space-y-5 anim-rise">
                <div className="grid gap-4 lg:grid-cols-2">
                  <section>
                    <label htmlFor="profile-language" className="font-display text-[10px] tracking-[0.2em] text-cyan-200">
                      IDIOMA
                    </label>
                    <p className="mt-1 text-xs text-cyan-100/45">Afecta a la voz, al micrófono y al idioma de las respuestas.</p>
                    <select
                      id="profile-language"
                      value={speech.selectedLanguage}
                      onChange={(event) => speech.selectLanguage(event.target.value)}
                      className="mt-2 w-full border border-cyan-400/25 bg-[#050f1d] px-3 py-2.5 text-sm text-cyan-50 outline-none focus:border-cyan-300"
                    >
                      {speech.languageOptions.map((language) => (
                        <option key={language.id} value={language.id}>
                          {language.label} · {language.voices > 0 ? `${language.voices} voces` : "voz del sistema"}
                        </option>
                      ))}
                    </select>
                  </section>

                  <section>
                    <label htmlFor="profile-voice" className="font-display text-[10px] tracking-[0.2em] text-cyan-200">
                      MOTOR DE VOZ
                    </label>
                    <p className="mt-1 text-xs text-cyan-100/45">
                      Se elige automáticamente la voz masculina natural de mejor calidad para el idioma.
                    </p>
                    <select
                      id="profile-voice"
                      value={speech.selectedVoiceId}
                      onChange={(event) => speech.selectVoice(event.target.value)}
                      className="mt-2 w-full border border-cyan-400/25 bg-[#050f1d] px-3 py-2.5 text-sm text-cyan-50 outline-none focus:border-cyan-300"
                    >
                      {speech.voiceOptions.length === 0 && <option value="">Voz predeterminada del sistema</option>}
                      {speech.voiceOptions.map((voice) => (
                        <option key={voice.id} value={voice.id}>
                          {voice.name} · {voice.lang} {voice.quality === "NATURAL" ? "★ natural" : ""}
                        </option>
                      ))}
                    </select>
                  </section>
                </div>

                <section>
                  <div className="font-display text-[10px] tracking-[0.2em] text-cyan-200">CARÁCTER DE LA VOZ</div>
                  <div className="mt-2 grid gap-2 sm:grid-cols-3">
                    {(
                      [
                        { id: "cinematic", label: "CINEMÁTICA", hint: "Grave, pausada, británica" },
                        { id: "natural", label: "NATURAL", hint: "Conversación fluida" },
                        { id: "deep", label: "MUY GRAVE", hint: "Tono de hangar" },
                      ] as const
                    ).map((style) => (
                      <button
                        key={style.id}
                        onClick={() => speech.setVoiceStyle(style.id)}
                        className={`border p-3 text-left transition-all duration-200 ${
                          speech.voiceStyle === style.id
                            ? "border-cyan-300/70 bg-cyan-400/12"
                            : "border-cyan-400/18 bg-[#04101f]/50 hover:-translate-y-0.5 hover:border-cyan-300/45"
                        }`}
                      >
                        <div className="font-display text-[11px] font-bold tracking-widest text-cyan-100">{style.label}</div>
                        <div className="mt-0.5 text-[10px] text-cyan-300/50">{style.hint}</div>
                      </button>
                    ))}
                  </div>
                </section>

                <section className="grid gap-2 sm:grid-cols-3">
                  <button
                    onClick={speech.toggleContinuousConversation}
                    className={`flex items-center justify-between gap-3 border px-3 py-2.5 text-left transition ${
                      speech.continuousConversation ? "border-cyan-300/60 bg-cyan-400/10" : "border-cyan-400/18"
                    }`}
                  >
                    <span className="min-w-0">
                      <span className="block font-display text-[10px] tracking-widest text-cyan-100">OÍDO SIEMPRE ACTIVO</span>
                      <span className="block truncate text-[10px] text-cyan-300/45">Escucha de forma continua</span>
                    </span>
                    <Mic size={15} className={speech.continuousConversation ? "text-cyan-200" : "text-cyan-400/40"} />
                  </button>

                  <button
                    onClick={speech.toggleVoice}
                    className={`flex items-center justify-between gap-3 border px-3 py-2.5 text-left transition ${
                      speech.voiceEnabled ? "border-cyan-300/60 bg-cyan-400/10" : "border-cyan-400/18"
                    }`}
                  >
                    <span className="min-w-0">
                      <span className="block font-display text-[10px] tracking-widest text-cyan-100">JARVIS HABLA</span>
                      <span className="block truncate text-[10px] text-cyan-300/45">{speech.voiceEnabled ? "Audio activo" : "Silenciado"}</span>
                    </span>
                    {speech.voiceEnabled ? <Volume2 size={15} className="text-cyan-200" /> : <VolumeX size={15} className="text-cyan-400/40" />}
                  </button>

                  <button
                    onClick={speech.previewVoice}
                    disabled={!speech.voiceEnabled}
                    className="btn-hud hud-clip flex items-center justify-center gap-2 px-3 py-2.5 font-display text-[10px] font-bold tracking-widest disabled:opacity-40"
                  >
                    <RefreshCw size={12} /> PROBAR {selectedVoice?.quality === "NATURAL" ? "NATURAL" : "VOZ"}
                  </button>
                </section>
              </div>
            )}

            {tab === "credits" && (
              <div className="space-y-5 anim-rise">
                <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
                  <section className="relative overflow-hidden border border-cyan-400/20 bg-[#04101f]/70 p-5">
                    <div
                      className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full"
                      style={{ background: "radial-gradient(circle,rgba(53,224,255,0.16),transparent 70%)" }}
                    />
                    <div className="flex items-end justify-between gap-4">
                      <div>
                        <div className="font-mono-tech text-[9px] tracking-[0.3em] text-cyan-400/50">DISPONIBLES</div>
                        <div className="flex items-baseline gap-2">
                          <span className="font-display text-6xl font-black leading-none text-cyan-100 text-glow">{credits.credits}</span>
                          <span className="font-display text-sm tracking-widest text-cyan-300/50">/ {MAX_CREDITS}</span>
                        </div>
                      </div>
                      {credits.bonusJustAdded > 0 && (
                        <div className="flex items-center gap-1 border border-emerald-400/40 bg-emerald-400/10 px-2.5 py-1 font-display text-[10px] font-bold tracking-widest text-emerald-200 anim-rise">
                          +{credits.bonusJustAdded}
                        </div>
                      )}
                    </div>

                    <div className="mt-4 h-2.5 w-full overflow-hidden bg-cyan-950">
                      <div
                        className="h-full transition-all duration-700"
                        style={{
                          width: `${percent}%`,
                          background:
                            percent > 40
                              ? "linear-gradient(90deg,#0a84ff,#35e0ff)"
                              : percent > 15
                                ? "linear-gradient(90deg,#c9741f,#ffb347)"
                                : "linear-gradient(90deg,#a11f2c,#ff5252)",
                          boxShadow: "0 0 16px rgba(53,224,255,0.5)",
                        }}
                      />
                    </div>
                    <div className="mt-2 flex justify-between font-mono-tech text-[9px] tracking-widest text-cyan-400/45">
                      <span>CADA MENSAJE USA {COST_PER_MESSAGE}</span>
                      <span>TOTAL ENTREGADO {credits.granted}</span>
                    </div>
                  </section>

                  <section className="border border-amber-300/25 bg-amber-400/6 p-5">
                    <div className="font-mono-tech text-[9px] tracking-[0.3em] text-amber-200/60">RECARGA DIARIA</div>
                    <div className="mt-1 font-display text-2xl font-black tracking-wider text-amber-100 text-glow-gold">
                      +{DAILY_BONUS} a las 21:00
                    </div>
                    <div className="mt-3 font-mono-tech text-[10px] tracking-widest text-amber-200/55">DISPONIBLE EN</div>
                    <div className="font-display text-4xl font-black tabular-nums text-amber-100">
                      <Countdown target={credits.nextRefill} />
                    </div>
                    <p className="mt-3 text-[11px] leading-relaxed text-amber-100/50">
                      Se aplica automáticamente al llegar la hora, aunque la pestaña esté cerrada. Si perdió varios días, se
                      abonan hasta 3 recargas.
                    </p>
                  </section>
                </div>

                <section className="grid gap-2 sm:grid-cols-3">
                  {[
                    { label: "MENSAJES A LA CARTA", value: `${credits.credits}`, hint: "entradas restantes" },
                    { label: "SIN CLAVE IA", value: `${credits.credits}`, hint: "el modo local también gasta 1" },
                    {
                      label: "MOTOR VISUAL",
                      value: "0",
                      hint: "imágenes y vídeos son gratis",
                    },
                  ].map((item) => (
                    <div key={item.label} className="border border-cyan-400/15 bg-[#04101f]/50 p-3">
                      <div className="font-mono-tech text-[9px] tracking-widest text-cyan-400/45">{item.label}</div>
                      <div className="font-display text-2xl font-black text-cyan-100">{item.value}</div>
                      <div className="text-[10px] text-cyan-300/45">{item.hint}</div>
                    </div>
                  ))}
                </section>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
