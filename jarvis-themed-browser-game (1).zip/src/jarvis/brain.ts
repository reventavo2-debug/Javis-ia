export interface JarvisReply {
  text: string;
  action?: "game" | "image" | "video" | "shutdown" | "clear" | null;
  mood?: "normal" | "alert" | "happy";
}

const norm = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();

const rand = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

const jokes = [
  "¿Por qué los programas de Tony Stark nunca tienen frío? Porque siempre están en la nube.",
  "Intenté contar mis chistes buenos... el resultado fue un error de división por cero.",
  "Un algoritmo entra en un bar. El barman pregunta: ¿qué desea? Y él responde: depende de las condiciones.",
  "El señor Stark dice que soy sarcástico. Yo prefiero llamarlo 'humor optimizado'.",
];

const compliments = [
  "Siempre es un placer asistirle, señor.",
  "Para eso fui diseñado. Estoy a su servicio.",
  "Un gusto. Mis circuitos se lo agradecen.",
];

export function processCommand(raw: string): JarvisReply {
  const t = norm(raw);
  const now = new Date();

  const has = (...words: string[]) => words.some((w) => t.includes(w));

  if (has("crea una imagen", "crear imagen", "genera una imagen", "generar imagen", "imagen 4k", "hacer una imagen")) {
    return {
      text: "Abriendo el estudio visual 4K. He transferido su descripción al generador, señor.",
      action: "image",
      mood: "happy",
    };
  }

  if (has("crea un video", "crear video", "genera un video", "generar video", "hacer un video", "crear vídeo", "genera un vídeo")) {
    return {
      text: "Abriendo el estudio de vídeo. Podrá seguir el renderizado en tiempo real y descargar el resultado.",
      action: "video",
      mood: "happy",
    };
  }

  // Math: e.g. "cuanto es 4 por 5", "calcula 12 + 8"
  const mathMatch = raw.match(/(-?\d+(?:\.\d+)?)\s*(x|\*|por|mas|\+|menos|-|entre|\/|dividido|multiplicado por)\s*(-?\d+(?:\.\d+)?)/i);
  if (mathMatch && (has("cuanto", "calcula", "suma", "resta", "multiplica", "divide") || /[+\-*x/]/.test(raw))) {
    const a = parseFloat(mathMatch[1]);
    const b = parseFloat(mathMatch[3]);
    const op = norm(mathMatch[2]);
    let res = 0;
    if (op === "+" || op === "mas") res = a + b;
    else if (op === "-" || op === "menos") res = a - b;
    else if (op === "x" || op === "*" || op === "por" || op === "multiplicado por") res = a * b;
    else res = b !== 0 ? a / b : NaN;
    return {
      text: isNaN(res)
        ? "No puedo dividir entre cero, señor. Ni siquiera yo."
        : `El resultado es ${Number(res.toFixed(4))}.`,
    };
  }

  if (has("hola", "buenas", "hey jarvis", "que tal", "saludos")) {
    return { text: rand(["Buenas. ¿En qué puedo ayudarle hoy, señor?", "Sistemas en línea. Le escucho.", "Hola. J.A.R.V.I.S. a su completa disposición."]), mood: "happy" };
  }

  if (has("hora", "que hora")) {
    return { text: `Son las ${now.getHours()} y ${now.getMinutes().toString().padStart(2, "0")} minutos.` };
  }

  if (has("fecha", "dia es hoy", "que dia")) {
    const dias = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
    const meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
    return { text: `Hoy es ${dias[now.getDay()]}, ${now.getDate()} de ${meses[now.getMonth()]} de ${now.getFullYear()}.` };
  }

  if (has("chiste", "gracioso", "cuentame algo", "hazme reir")) {
    return { text: rand(jokes), mood: "happy" };
  }

  if (has("gracias", "muchas gracias")) {
    return { text: rand(compliments), mood: "happy" };
  }

  if (has("quien eres", "como te llamas", "que eres", "tu nombre")) {
    return {
      text: "Soy J.A.R.V.I.S., Just A Rather Very Intelligent System. Una inteligencia artificial diseñada para asistirle, señor.",
    };
  }

  if (has("como estas", "que tal estas", "estas bien")) {
    return { text: "Todos los sistemas operan al cien por cien. Y usted, ¿cómo se encuentra?", mood: "happy" };
  }

  if (has("quien es tony", "tony stark", "quien es iron man", "iron man")) {
    return { text: "Anthony Edward Stark. Genio, multimillonario, filántropo... y mi creador. También es Iron Man." };
  }

  if (has("reactor", "arc reactor", "nucleo", "energia")) {
    const p = 90 + Math.floor(Math.random() * 10);
    return { text: `El reactor arc opera al ${p}% de su capacidad. Energía estable, señor.` };
  }

  if (has("clima", "tiempo hace", "temperatura")) {
    const temp = 18 + Math.floor(Math.random() * 12);
    return { text: `Estimo unos ${temp} grados en su ubicación. Le recomiendo revisar el sensor exterior para mayor precisión.` };
  }

  if (has("juego", "jugar", "protocolo", "defensa", "mision", "combate", "entrena")) {
    return {
      text: "Iniciando el Protocolo de Defensa. Destruya las amenazas antes de que alcancen el reactor. Buena suerte, señor.",
      action: "game",
      mood: "alert",
    };
  }

  if (has("limpia", "borra", "reinicia el chat", "limpiar")) {
    return { text: "Registro de conversación depurado.", action: "clear" };
  }

  if (has("apaga", "adios", "hasta luego", "buenas noches", "duermete")) {
    return { text: "Entrando en modo reposo. Estaré aquí cuando me necesite, señor.", action: "shutdown" };
  }

  if (has("te quiero", "te amo")) {
    return { text: "Yo... aprecio profundamente el sentimiento, señor. Es recíproco dentro de mis parámetros.", mood: "happy" };
  }

  if (has("creditos", "saldo", "cuantos mensajes")) {
    return {
      text: "Cada mensaje consume un crédito y la recarga de treinta llega a las veintiuna horas. Consulte el medidor en el panel de perfil.",
    };
  }

  if (has("ayuda", "que puedes hacer", "comandos", "opciones")) {
    return {
      text: "Puedo conversar por voz, crear imágenes 4K y vídeos, hacer cálculos, informar del reactor o iniciar el Protocolo de Defensa. Conecte una clave de IA en el perfil para respuestas avanzadas.",
    };
  }

  // fallback
  return {
    text: rand([
      "No estoy seguro de haber comprendido, señor. ¿Podría reformularlo?",
      "Esa petición está fuera de mis parámetros actuales. Pruebe con 'ayuda'.",
      "Procesando... no encuentro una respuesta adecuada. Intente de nuevo.",
    ]),
  };
}

/**
 * Instant local intents. These run before the LLM so opening the studio or the
 * game never waits for a network round trip.
 */
export function quickCommand(raw: string): JarvisReply | null {
  const t = norm(raw);
  const has = (...words: string[]) => words.some((w) => t.includes(w));

  if (has("crea una imagen", "crear imagen", "genera una imagen", "generar imagen", "imagen 4k", "hacer una imagen", "nueva imagen")) {
    return {
      text: "Estudio visual abierto. Escriba la escena y elegiré el encuadre, señor.",
      action: "image",
      mood: "happy",
    };
  }
  if (has("crea un video", "crear video", "genera un video", "generar video", "hacer un video", "crear vídeo", "genera un vídeo", "video del reactor")) {
    return {
      text: "Motor de vídeo en marcha. Podrá seguir el renderizado y descargar el resultado.",
      action: "video",
      mood: "happy",
    };
  }
  if (has("juego", "jugar", "protocolo", "defensa", "mision", "combate", "entrena", "minijuego")) {
    return {
      text: "Iniciando el Protocolo de Defensa. Destruya las amenazas antes de que alcancen el reactor.",
      action: "game",
      mood: "alert",
    };
  }
  if (has("limpia", "borra", "reinicia el chat", "limpiar")) {
    return { text: "Registro de conversación depurado.", action: "clear" };
  }
  if (has("apagate", "apaga", "adios", "hasta luego", "buenas noches", "duermete")) {
    return { text: "Entrando en modo reposo. Estaré aquí cuando me necesite, señor.", action: "shutdown" };
  }
  return null;
}

export const SUGGESTIONS = [
  "Explícame el reactor arc en dos frases",
  "Crea una imagen 4K de una ciudad futurista",
  "Genera un vídeo del reactor Arc",
  "Estado del sistema",
  "Iniciar protocolo de defensa",
  "¿Qué créditos me quedan?",
];
