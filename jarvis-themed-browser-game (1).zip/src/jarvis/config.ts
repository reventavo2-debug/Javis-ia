import { useCallback, useEffect, useState } from "react";

export interface JarvisConfig {
  apiKey: string;
  geminiApiKey: string;
  model: string;
  useLlm: boolean;
}

const CONFIG_KEY = "jarvis_llm_config";
const EVENT = "jarvis-config-changed";

export const MODELS = [
  { id: "openai/gpt-5.4-nano", label: "Nano · respuesta instantánea", tier: "RÁPIDO" },
  { id: "openai/gpt-5.4-mini", label: "Mini · equilibrio calidad/velocidad", tier: "EQUILIBRIO" },
  { id: "google/gemini-3.5-flash-lite", label: "Flash Lite · multilingüe", tier: "RÁPIDO" },
  { id: "openai/gpt-4o-mini", label: "GPT-4o mini · muy natural", tier: "EQUILIBRIO" },
  { id: "anthropic/claude-haiku-4.5", label: "Haiku · reasoning fino", tier: "AVANZADO" },
  { id: "deepseek/deepseek-v4-flash", label: "DeepSeek · analítico", tier: "AVANZADO" },
] as const;

function read(): JarvisConfig {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<JarvisConfig>;
      return {
        apiKey: typeof parsed.apiKey === "string" ? parsed.apiKey : "",
        geminiApiKey: typeof parsed.geminiApiKey === "string" ? parsed.geminiApiKey : "",
        model: MODELS.some((m) => m.id === parsed.model) ? parsed.model! : MODELS[0].id,
        useLlm: parsed.useLlm !== false,
      };
    }
  } catch {
    /* ignore malformed storage */
  }
  return { apiKey: "", geminiApiKey: "", model: MODELS[0].id, useLlm: true };
}

export function saveConfig(patch: Partial<JarvisConfig>) {
  const next = { ...read(), ...patch };
  localStorage.setItem(CONFIG_KEY, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent(EVENT));
  return next;
}

/** Shared config so the assistant, the profile panel and the studio stay in sync. */
export function useJarvisConfig() {
  const [config, setConfig] = useState<JarvisConfig>(read);

  useEffect(() => {
    const sync = () => setConfig(read());
    window.addEventListener(EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const update = useCallback((patch: Partial<JarvisConfig>) => setConfig(saveConfig(patch)), []);
  const ready = config.useLlm && (config.geminiApiKey.trim().length > 6 || config.apiKey.trim().length > 6);

  return { config, update, ready };
}
