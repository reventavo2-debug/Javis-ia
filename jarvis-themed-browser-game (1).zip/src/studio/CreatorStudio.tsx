import { useCallback, useEffect, useRef, useState } from "react";
import { Coins } from "lucide-react";
import { useJarvisConfig } from "../jarvis/config";
import { useCredits } from "../hooks/useCredits";

export type StudioMode = "image" | "video";
type StudioEngine = "local" | "ai";
type AspectRatio = "16:9" | "1:1" | "9:16";

interface CreatorStudioProps {
  initialMode: StudioMode;
  initialPrompt: string;
  onExit: () => void;
}

interface Palette {
  sky: string;
  deep: string;
  glow: string;
  accent: string;
  warm: string;
}

const STYLE_PROMPTS: Record<string, string> = {
  cinematic: "cinematic masterpiece, volumetric lighting, epic composition, physically accurate materials, fine details, professional color grading",
  cosmic: "deep space, luminous nebula, monumental scale, intricate detail, cinematic astrophotography",
  noir: "futuristic noir, deep shadows, rim lighting, atmospheric fog, premium concept art, intricate detail",
  clean: "clean futuristic design, technical precision, soft studio lighting, premium product visualization, immaculate details",
};

const ASPECTS: Record<AspectRatio, { image: [number, number]; preview: [number, number]; ai: [number, number] }> = {
  "16:9": { image: [3840, 2160], preview: [1280, 720], ai: [1536, 864] },
  "1:1": { image: [3072, 3072], preview: [900, 900], ai: [1024, 1024] },
  "9:16": { image: [2160, 3840], preview: [720, 1280], ai: [864, 1536] },
};

function extensionForMime(mime: string) {
  if (mime.includes("mp4")) return "mp4";
  if (mime.includes("png")) return "png";
  if (mime.includes("jpeg")) return "jpg";
  return "webm";
}

function supportedVideoMime() {
  const candidates = [
    "video/webm;codecs=vp9",
    "video/webm;codecs=vp8",
    "video/mp4;codecs=avc1.42E01E",
    "video/mp4",
    "video/webm",
  ];
  return candidates.find((type) => MediaRecorder.isTypeSupported(type)) || "";
}

function readErrorMessage(payload: unknown) {
  if (typeof payload === "string") return payload;
  if (payload && typeof payload === "object") {
    const body = payload as { error?: { message?: string }; message?: string };
    return body.error?.message || body.message || "El proveedor no pudo completar la generación.";
  }
  return "El proveedor no pudo completar la generación.";
}

async function blobToDrawable(blob: Blob): Promise<CanvasImageSource> {
  if ("createImageBitmap" in window) return createImageBitmap(blob);
  const url = URL.createObjectURL(blob);
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      URL.revokeObjectURL(url);
      resolve(image);
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("No se pudo decodificar la imagen generada."));
    };
    image.src = url;
  });
}

async function responseError(response: Response) {
  try {
    return readErrorMessage(await response.clone().json());
  } catch {
    try {
      return readErrorMessage(await response.text());
    } catch {
      return `Error del proveedor (${response.status}).`;
    }
  }
}

function hashString(value: string) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index++) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function randomGenerator(seed: number) {
  return () => {
    seed += 0x6d2b79f5;
    let value = seed;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function paletteForPrompt(prompt: string): Palette {
  const text = prompt.toLowerCase();
  if (/fuego|lava|sol|desierto|rojo/.test(text)) {
    return { sky: "#401422", deep: "#07040a", glow: "#ff6636", accent: "#ffbd59", warm: "#ff315f" };
  }
  if (/bosque|naturaleza|verde|selva/.test(text)) {
    return { sky: "#0c352f", deep: "#020c0c", glow: "#50ffc0", accent: "#d4ff70", warm: "#f6cc6b" };
  }
  if (/océano|oceano|mar|agua/.test(text)) {
    return { sky: "#123b65", deep: "#020914", glow: "#35e0ff", accent: "#65a6ff", warm: "#ff83c6" };
  }
  if (/espacio|cosmos|galaxia|nebulosa/.test(text)) {
    return { sky: "#281457", deep: "#03030d", glow: "#a678ff", accent: "#35e0ff", warm: "#ff65bd" };
  }
  return { sky: "#073b55", deep: "#020711", glow: "#35e0ff", accent: "#2d85ff", warm: "#ffb347" };
}

function drawScene(
  context: CanvasRenderingContext2D,
  width: number,
  height: number,
  prompt: string,
  time = 0,
  quality = 1,
) {
  const palette = paletteForPrompt(prompt);
  const seed = hashString(prompt || "jarvis creative core");
  const random = randomGenerator(seed);
  const scale = Math.min(width, height);

  context.clearRect(0, 0, width, height);
  const sky = context.createLinearGradient(0, 0, 0, height);
  sky.addColorStop(0, palette.deep);
  sky.addColorStop(0.52, palette.sky);
  sky.addColorStop(1, "#02050b");
  context.fillStyle = sky;
  context.fillRect(0, 0, width, height);

  // Layered translucent light fields create a nebula without expensive filters.
  const clouds = Math.round(18 * quality);
  for (let index = 0; index < clouds; index++) {
    const x = random() * width + Math.sin(time * 0.2 + index) * width * 0.02;
    const y = random() * height * 0.72;
    const radius = (0.05 + random() * 0.22) * scale;
    const color = index % 3 === 0 ? palette.warm : index % 2 === 0 ? palette.accent : palette.glow;
    const cloud = context.createRadialGradient(x, y, 0, x, y, radius);
    cloud.addColorStop(0, `${color}28`);
    cloud.addColorStop(0.5, `${color}0d`);
    cloud.addColorStop(1, `${color}00`);
    context.fillStyle = cloud;
    context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }

  const stars = Math.round((width >= 3000 ? 920 : 280) * quality);
  for (let index = 0; index < stars; index++) {
    const x = random() * width;
    const y = random() * height * 0.74;
    const twinkle = 0.35 + Math.sin(time * 2 + index * 0.73) * 0.25;
    const radius = (0.35 + random() * 1.4) * (width / 1280);
    context.globalAlpha = Math.max(0.14, twinkle + random() * 0.35);
    context.fillStyle = index % 12 === 0 ? palette.glow : "#e9f8ff";
    context.beginPath();
    context.arc(x, y, radius, 0, Math.PI * 2);
    context.fill();
  }
  context.globalAlpha = 1;

  const planetX = width * (0.72 + Math.sin(time * 0.08) * 0.012);
  const planetY = height * 0.32;
  const planetRadius = scale * 0.19;
  const planetGlow = context.createRadialGradient(planetX, planetY, planetRadius * 0.45, planetX, planetY, planetRadius * 1.35);
  planetGlow.addColorStop(0, `${palette.accent}24`);
  planetGlow.addColorStop(0.7, `${palette.glow}12`);
  planetGlow.addColorStop(1, `${palette.glow}00`);
  context.fillStyle = planetGlow;
  context.beginPath();
  context.arc(planetX, planetY, planetRadius * 1.35, 0, Math.PI * 2);
  context.fill();

  const planet = context.createRadialGradient(
    planetX - planetRadius * 0.35,
    planetY - planetRadius * 0.4,
    planetRadius * 0.04,
    planetX,
    planetY,
    planetRadius,
  );
  planet.addColorStop(0, "#dffaff");
  planet.addColorStop(0.1, palette.glow);
  planet.addColorStop(0.52, palette.accent);
  planet.addColorStop(1, palette.deep);
  context.fillStyle = planet;
  context.beginPath();
  context.arc(planetX, planetY, planetRadius, 0, Math.PI * 2);
  context.fill();

  context.save();
  context.translate(planetX, planetY);
  context.rotate(-0.22 + time * 0.015);
  context.strokeStyle = `${palette.glow}8c`;
  context.lineWidth = Math.max(1, width / 900);
  context.beginPath();
  context.ellipse(0, 0, planetRadius * 1.5, planetRadius * 0.3, 0, 0, Math.PI * 2);
  context.stroke();
  context.restore();

  const horizon = height * 0.72;
  const cityPrompt = /ciudad|city|torre|edificio|urbano|futur/.test(prompt.toLowerCase());
  const buildings = cityPrompt ? 58 : 28;
  let cursor = -width * 0.02;
  for (let index = 0; index < buildings; index++) {
    const buildingWidth = width * (0.009 + random() * 0.023);
    const buildingHeight = height * (0.035 + random() * (cityPrompt ? 0.24 : 0.1));
    context.fillStyle = index % 4 === 0 ? "#071628" : "#040b15";
    context.fillRect(cursor, horizon - buildingHeight, buildingWidth, buildingHeight);
    if (cityPrompt) {
      context.fillStyle = `${index % 7 === 0 ? palette.warm : palette.glow}9c`;
      const rows = Math.floor(buildingHeight / (height * 0.018));
      for (let row = 1; row < rows; row++) {
        if (random() > 0.42) {
          context.fillRect(cursor + buildingWidth * 0.2, horizon - buildingHeight + row * height * 0.018, buildingWidth * 0.12, height * 0.003);
        }
      }
    }
    cursor += buildingWidth + width * 0.002;
  }

  const floor = context.createLinearGradient(0, horizon, 0, height);
  floor.addColorStop(0, `${palette.sky}a8`);
  floor.addColorStop(1, "#010306");
  context.fillStyle = floor;
  context.fillRect(0, horizon, width, height - horizon);

  context.strokeStyle = `${palette.glow}36`;
  context.lineWidth = Math.max(1, width / 1600);
  const vanishingX = width * 0.5;
  for (let index = -12; index <= 12; index++) {
    context.beginPath();
    context.moveTo(vanishingX, horizon);
    context.lineTo(vanishingX + index * width * 0.09, height);
    context.stroke();
  }
  for (let row = 0; row < 14; row++) {
    const ratio = row / 13;
    const y = horizon + Math.pow(ratio, 1.8) * (height - horizon);
    context.beginPath();
    context.moveTo(0, y);
    context.lineTo(width, y);
    context.stroke();
  }

  if (/jarvis|reactor|robot|armadura|iron/.test(prompt.toLowerCase())) {
    const coreX = width * 0.32;
    const coreY = height * 0.48;
    const coreRadius = scale * 0.11;
    context.save();
    context.translate(coreX, coreY);
    context.rotate(time * 0.25);
    context.strokeStyle = palette.glow;
    context.lineWidth = Math.max(2, width / 500);
    context.setLineDash([coreRadius * 0.25, coreRadius * 0.13]);
    context.beginPath();
    context.arc(0, 0, coreRadius * 1.5, 0, Math.PI * 2);
    context.stroke();
    context.rotate(-time * 0.5);
    context.strokeStyle = palette.warm;
    context.beginPath();
    context.arc(0, 0, coreRadius * 1.18, 0, Math.PI * 2);
    context.stroke();
    context.setLineDash([]);
    const core = context.createRadialGradient(0, 0, 0, 0, 0, coreRadius);
    core.addColorStop(0, "#ffffff");
    core.addColorStop(0.24, palette.glow);
    core.addColorStop(1, `${palette.accent}00`);
    context.fillStyle = core;
    context.beginPath();
    context.arc(0, 0, coreRadius, 0, Math.PI * 2);
    context.fill();
    context.restore();
  }

  // Cinematic vignette and letterbox-safe contrast.
  const vignette = context.createRadialGradient(width / 2, height / 2, scale * 0.1, width / 2, height / 2, width * 0.72);
  vignette.addColorStop(0, "#00000000");
  vignette.addColorStop(0.72, "#00000010");
  vignette.addColorStop(1, "#000000b8");
  context.fillStyle = vignette;
  context.fillRect(0, 0, width, height);
}

function cleanPrompt(prompt: string) {
  return prompt
    .replace(/^(crea|crear|genera|generar|haz|hacer)\s+(una?|el)?\s*(imagen|vídeo|video)(\s+4k)?\s*(de|del)?\s*/i, "")
    .trim();
}

export default function CreatorStudio({ initialMode, initialPrompt, onExit }: CreatorStudioProps) {
  const [mode, setMode] = useState<StudioMode>(initialMode);
  const [engine, setEngine] = useState<StudioEngine>("local");
  const [prompt, setPrompt] = useState(cleanPrompt(initialPrompt));
  const [style, setStyle] = useState("cinematic");
  const [aspect, setAspect] = useState<AspectRatio>("16:9");
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 2_000_000_000));
  const { config, update } = useJarvisConfig();
  const credits = useCredits();
  const apiKey = config.geminiApiKey || config.apiKey;
  const setApiKey = (value: string) => update({ apiKey: value });
  const [progress, setProgress] = useState(0);
  const [generating, setGenerating] = useState(false);
  const [status, setStatus] = useState("LISTO PARA CREAR");
  const [error, setError] = useState("");
  const [resultUrl, setResultUrl] = useState("");
  const [resultType, setResultType] = useState<StudioMode | null>(null);
  const [resultMime, setResultMime] = useState("");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const resultUrlRef = useRef("");
  const animationRef = useRef(0);
  const jobRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);

  const composedPrompt = `${prompt || "universo futurista JARVIS"}, ${STYLE_PROMPTS[style]}, ultra detailed, high fidelity, sharp focus, coherent geometry, no text, no watermark`;
  const dimensions = ASPECTS[aspect];

  const prepareCanvas = useCallback((width: number, height: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    if (canvas.width !== width) canvas.width = width;
    if (canvas.height !== height) canvas.height = height;
    return canvas.getContext("2d", { alpha: false });
  }, []);

  const clearResult = useCallback(() => {
    if (resultUrlRef.current) URL.revokeObjectURL(resultUrlRef.current);
    resultUrlRef.current = "";
    setResultUrl("");
    setResultType(null);
    setResultMime("");
  }, []);

  useEffect(() => {
    const [width, height] = dimensions.preview;
    const context = prepareCanvas(width, height);
    if (context) drawScene(context, width, height, composedPrompt, 0, 0.8);
  }, [composedPrompt, dimensions.preview, mode, prepareCanvas]);

  useEffect(() => {
    resultUrlRef.current = resultUrl;
  }, [resultUrl]);

  useEffect(
    () => () => {
      jobRef.current += 1;
      abortRef.current?.abort();
      cancelAnimationFrame(animationRef.current);
      if (resultUrlRef.current) URL.revokeObjectURL(resultUrlRef.current);
    },
    [],
  );

  const generateImage = useCallback(() => {
    const job = ++jobRef.current;
    clearResult();
    setError("");
    setGenerating(true);
    setProgress(1);
    setStatus("INTERPRETANDO DESCRIPCIÓN");
    const started = performance.now();
    const duration = 2200;

    const tick = (now: number) => {
      if (jobRef.current !== job) return;
      const ratio = Math.min((now - started) / duration, 1);
      const percent = Math.min(96, Math.round(ratio * 96));
      setProgress(percent);
      setStatus(percent < 28 ? "INTERPRETANDO DESCRIPCIÓN" : percent < 68 ? "COMPONIENDO ESCENA" : "RENDERIZANDO 4K");

      if (ratio < 1) {
        animationRef.current = requestAnimationFrame(tick);
        return;
      }

      const [outputWidth, outputHeight] = dimensions.image;
      const context = prepareCanvas(outputWidth, outputHeight);
      if (!context) {
        setError("No se pudo preparar el lienzo de la imagen.");
        setStatus("ERROR DE RENDERIZADO");
        setGenerating(false);
        return;
      }
      drawScene(context, outputWidth, outputHeight, `${composedPrompt}, seed ${seed}`, 0, 1.1);
      setStatus("CODIFICANDO PNG 4K");
      canvasRef.current?.toBlob(
        (blob) => {
          if (jobRef.current !== job) return;
          if (!blob || blob.size < 1024) {
            setError("El navegador no pudo codificar la imagen 4K. Pruebe otro formato o navegador.");
            setStatus("ERROR AL CREAR LA IMAGEN");
            setGenerating(false);
            return;
          }
          const url = URL.createObjectURL(blob);
          resultUrlRef.current = url;
          setResultUrl(url);
          setResultType("image");
          setResultMime("image/png");
          setProgress(100);
          setStatus("IMAGEN 4K COMPLETADA");
          setGenerating(false);
        },
        "image/png",
        1,
      );
    };
    animationRef.current = requestAnimationFrame(tick);
  }, [clearResult, composedPrompt, dimensions.image, prepareCanvas, seed]);

  const generateVideo = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !("MediaRecorder" in window) || !("captureStream" in canvas)) {
      setStatus("GRABACIÓN DE VÍDEO NO COMPATIBLE");
      return;
    }

    const job = ++jobRef.current;
    clearResult();
    setError("");
    setGenerating(true);
    setProgress(0);
    setStatus("INICIANDO MOTOR DE VÍDEO");
    const [videoWidth, videoHeight] = dimensions.preview;
    const context = prepareCanvas(videoWidth, videoHeight);
    if (!context) {
      setError("No se pudo preparar el lienzo del vídeo.");
      setStatus("ERROR DE RENDERIZADO");
      setGenerating(false);
      return;
    }

    const stream = canvas.captureStream(30);
    const preferred = supportedVideoMime();
    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(
        stream,
        preferred ? { mimeType: preferred, videoBitsPerSecond: 7_000_000 } : { videoBitsPerSecond: 7_000_000 },
      );
    } catch {
      stream.getTracks().forEach((track) => track.stop());
      setError("Este navegador no puede grabar el formato de vídeo local. Pruebe Chrome, Edge o Firefox.");
      setStatus("VÍDEO LOCAL NO COMPATIBLE");
      setGenerating(false);
      return;
    }
    const chunks: Blob[] = [];
    const duration = 6000;
    const started = performance.now();

    recorder.ondataavailable = (event) => {
      if (event.data.size) chunks.push(event.data);
    };
    recorder.onstop = () => {
      stream.getTracks().forEach((track) => track.stop());
      if (jobRef.current !== job) return;
      const mime = recorder.mimeType || preferred || "video/webm";
      const blob = new Blob(chunks, { type: mime });
      if (blob.size < 1024) {
        setError("La grabación terminó sin fotogramas reproducibles. Inténtelo de nuevo o utilice otro navegador.");
        setStatus("ERROR AL CREAR EL VÍDEO");
        setGenerating(false);
        return;
      }
      const url = URL.createObjectURL(blob);
      resultUrlRef.current = url;
      setResultUrl(url);
      setResultType("video");
      setResultMime(mime);
      setProgress(100);
      setStatus("VÍDEO COMPLETADO");
      setGenerating(false);
    };
    recorder.start(250);

    const frame = (now: number) => {
      if (jobRef.current !== job) {
        if (recorder.state !== "inactive") recorder.stop();
        return;
      }
      const elapsed = now - started;
      const ratio = Math.min(elapsed / duration, 1);
      const percent = Math.round(ratio * 100);
      drawScene(context, videoWidth, videoHeight, `${composedPrompt}, seed ${seed}`, elapsed / 1000, 0.9);
      setProgress(percent);
      setStatus(percent < 15 ? "DISEÑANDO SECUENCIA" : percent < 88 ? "RENDERIZANDO FOTOGRAMAS" : "CODIFICANDO VÍDEO");
      if (ratio < 1) animationRef.current = requestAnimationFrame(frame);
      else {
        try {
          recorder.requestData();
        } catch {
          // Some MediaRecorder implementations flush automatically on stop.
        }
        recorder.stop();
      }
    };
    animationRef.current = requestAnimationFrame(frame);
  }, [clearResult, composedPrompt, dimensions.preview, prepareCanvas, seed]);

  const generateAiImage = useCallback(async () => {
    const job = ++jobRef.current;
    clearResult();
    setError("");
    setGenerating(true);
    setProgress(2);
    setStatus("CONECTANDO CON EL MODELO IA");
    const controller = new AbortController();
    abortRef.current = controller;
    const progressTimer = window.setInterval(() => {
      setProgress((value) => Math.min(88, value + Math.max(1, Math.round((90 - value) * 0.07))));
    }, 650);

    try {
      const [aiWidth, aiHeight] = dimensions.ai;
      const params = new URLSearchParams({
        model: "tongyi-mai/z-image-turbo",
        width: String(aiWidth),
        height: String(aiHeight),
        seed: String(seed),
        quality: "high",
        safe: "true",
        key: apiKey.trim(),
      });
      setStatus("GENERANDO PÍXELES CON IA");
      const response = await fetch(
        `https://gen.pollinations.ai/image/${encodeURIComponent(composedPrompt)}?${params.toString()}`,
        { signal: controller.signal },
      );
      if (!response.ok) throw new Error(await responseError(response));
      const mime = response.headers.get("content-type") || "";
      if (!mime.startsWith("image/")) throw new Error(await responseError(response));
      const blob = await response.blob();
      if (jobRef.current !== job) return;

      setProgress(92);
      setStatus("REESCALANDO Y AFINANDO EN 4K");
      const source = await blobToDrawable(blob);
      const [outputWidth, outputHeight] = dimensions.image;
      const context = prepareCanvas(outputWidth, outputHeight);
      if (!context) throw new Error("No se pudo preparar el lienzo 4K.");
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = "high";
      context.filter = "contrast(1.045) saturate(1.06)";
      context.drawImage(source, 0, 0, outputWidth, outputHeight);
      context.filter = "none";
      if ("close" in source && typeof source.close === "function") source.close();

      setProgress(97);
      setStatus("CODIFICANDO PNG SIN PÉRDIDAS");
      const output = await new Promise<Blob>((resolve, reject) => {
        canvasRef.current?.toBlob(
          (file) => (file ? resolve(file) : reject(new Error("No se pudo codificar la imagen."))),
          "image/png",
          1,
        );
      });
      if (jobRef.current !== job) return;
      const url = URL.createObjectURL(output);
      resultUrlRef.current = url;
      setResultUrl(url);
      setResultType("image");
      setResultMime("image/png");
      setProgress(100);
      setStatus("IMAGEN IA 4K COMPLETADA");
    } catch (reason) {
      if ((reason as Error).name === "AbortError") return;
      setError(reason instanceof Error ? reason.message : "No se pudo generar la imagen con IA.");
      setStatus("ERROR DEL MOTOR IA");
    } finally {
      window.clearInterval(progressTimer);
      if (jobRef.current === job) setGenerating(false);
    }
  }, [apiKey, clearResult, composedPrompt, dimensions.ai, dimensions.image, prepareCanvas, seed]);

  const generateAiVideo = useCallback(async () => {
    const job = ++jobRef.current;
    clearResult();
    setError("");
    setGenerating(true);
    setProgress(1);
    setStatus("PREPARANDO MODELO DE VÍDEO IA");
    const controller = new AbortController();
    abortRef.current = controller;
    const progressTimer = window.setInterval(() => {
      setProgress((value) => Math.min(91, value + Math.max(1, Math.round((92 - value) * 0.045))));
    }, 800);

    try {
      const params = new URLSearchParams({
        model: "bytedance/seedance-2.0",
        resolution: "720p",
        duration: "6",
        aspectRatio: aspect,
        seed: String(seed),
        safe: "true",
        key: apiKey.trim(),
      });
      setStatus("SINTETIZANDO MOVIMIENTO Y FOTOGRAMAS");
      const response = await fetch(
        `https://gen.pollinations.ai/video/${encodeURIComponent(composedPrompt)}?${params.toString()}`,
        { signal: controller.signal },
      );
      if (!response.ok) throw new Error(await responseError(response));
      const mime = response.headers.get("content-type") || "video/mp4";
      if (!mime.startsWith("video/")) throw new Error(await responseError(response));
      setProgress(96);
      setStatus("DESCARGANDO VÍDEO FINAL");
      const blob = await response.blob();
      if (jobRef.current !== job) return;
      const url = URL.createObjectURL(blob);
      resultUrlRef.current = url;
      setResultUrl(url);
      setResultType("video");
      setResultMime(blob.type || mime);
      setProgress(100);
      setStatus("VÍDEO IA COMPLETADO");
    } catch (reason) {
      if ((reason as Error).name === "AbortError") return;
      setError(reason instanceof Error ? reason.message : "No se pudo generar el vídeo con IA.");
      setStatus("ERROR DEL MOTOR IA");
    } finally {
      window.clearInterval(progressTimer);
      if (jobRef.current === job) setGenerating(false);
    }
  }, [apiKey, aspect, clearResult, composedPrompt, seed]);

  const generate = () => {
    if (generating) return;
    if (engine === "ai") {
      if (mode === "image") void generateAiImage();
      else void generateAiVideo();
      return;
    }
    if (mode === "image") generateImage();
    else generateVideo();
  };

  const changeMode = (nextMode: StudioMode) => {
    if (generating) return;
    setMode(nextMode);
    setProgress(0);
    setStatus("LISTO PARA CREAR");
    clearResult();
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#030711]/78 px-3 py-3 backdrop-blur-sm sm:px-5 sm:py-4">
      <header className="mb-3 flex shrink-0 items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="font-display text-lg font-black tracking-[0.22em] text-cyan-100 text-glow sm:text-2xl">JARVIS STUDIO</div>
          <div className="font-mono-tech text-[9px] tracking-[0.25em] text-cyan-400/50">NÚCLEO CREATIVO HÍBRIDO</div>
        </div>

        <div className="flex items-center border border-cyan-400/25 bg-cyan-950/20 p-1">
          <button
            onClick={() => changeMode("image")}
            className={`px-3 py-1.5 font-display text-[10px] tracking-widest transition sm:px-5 ${mode === "image" ? "bg-cyan-400/20 text-cyan-100" : "text-cyan-300/45"}`}
          >
            IMAGEN 4K
          </button>
          <button
            onClick={() => changeMode("video")}
            className={`px-3 py-1.5 font-display text-[10px] tracking-widest transition sm:px-5 ${mode === "video" ? "bg-cyan-400/20 text-cyan-100" : "text-cyan-300/45"}`}
          >
            VÍDEO
          </button>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-2 border border-amber-300/30 bg-amber-400/8 px-2.5 py-1.5 sm:flex" title="Créditos de JARVIS">
            <Coins size={12} className="text-amber-300" />
            <span className="font-display text-xs font-black tabular-nums text-amber-100">{credits.credits}</span>
          </div>
          <button onClick={onExit} className="btn-hud hud-clip px-3 py-2 font-display text-[10px] tracking-widest sm:px-5">
            VOLVER
          </button>
        </div>
      </header>

      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-[minmax(0,1fr)_320px]">
        <section className="hud-panel hud-clip relative flex min-h-0 items-center justify-center overflow-hidden bg-black/40">
          <canvas ref={canvasRef} className="h-full w-full object-contain" />
          <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-center justify-between bg-gradient-to-b from-black/70 to-transparent p-4">
            <span className="font-mono-tech text-[10px] tracking-widest text-cyan-200/70">
              {mode === "image"
                ? `${dimensions.image[0]} x ${dimensions.image[1]} / PNG`
                : `${engine === "ai" ? "IA 720P" : `${dimensions.preview[0]} x ${dimensions.preview[1]}`} / ${aspect}`}
            </span>
            <span className="font-mono-tech text-[10px] tracking-widest text-cyan-200/70">{status}</span>
          </div>

          {generating && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-[#020711]/55 backdrop-blur-[2px]">
              <div className="font-display text-5xl font-black text-cyan-100 text-glow sm:text-7xl">{progress}%</div>
              <div className="mt-3 font-mono-tech text-[10px] tracking-[0.3em] text-cyan-300/70">{status}</div>
              <div className="mt-5 h-1 w-52 overflow-hidden bg-cyan-950 sm:w-72">
                <div
                  className="h-full bg-cyan-300 transition-[width] duration-100"
                  style={{ width: `${progress}%`, boxShadow: "0 0 16px #35e0ff" }}
                />
              </div>
            </div>
          )}

          {!generating && resultType === "image" && resultUrl && (
            <img
              src={resultUrl}
              alt={prompt || "Imagen creada en JARVIS Studio"}
              className="absolute inset-0 z-10 h-full w-full bg-black object-contain anim-rise"
              draggable={false}
              onLoad={() => setStatus(engine === "ai" ? "IMAGEN IA 4K LISTA" : "IMAGEN LOCAL 4K LISTA")}
              onError={() => {
                setError("La imagen se creó, pero el navegador no pudo mostrar la previsualización.");
                setStatus("ERROR DE PREVISUALIZACIÓN");
              }}
            />
          )}

          {!generating && resultType === "video" && resultUrl && (
            <video
              key={resultUrl}
              src={resultUrl}
              controls
              autoPlay
              loop
              muted
              playsInline
              preload="auto"
              className="absolute inset-0 z-10 h-full w-full bg-black object-contain anim-rise"
              onLoadedData={() => setStatus(engine === "ai" ? "VÍDEO IA LISTO" : "VÍDEO LOCAL LISTO")}
              onError={() => {
                setError("El archivo de vídeo se creó, pero este navegador no puede reproducir su formato.");
                setStatus("FORMATO DE VÍDEO NO REPRODUCIBLE");
              }}
            />
          )}
        </section>

        <aside className="hud-panel hud-clip jv-scroll flex min-h-0 flex-col overflow-y-auto p-4 sm:p-5">
          <div className="grid grid-cols-2 gap-1 border border-cyan-400/20 bg-[#041020] p-1">
            <button
              onClick={() => {
                if (!generating) {
                  setEngine("local");
                  setError("");
                }
              }}
              className={`px-2 py-2 font-display text-[9px] tracking-widest transition ${engine === "local" ? "bg-cyan-400/20 text-cyan-100" : "text-cyan-300/45"}`}
            >
              LOCAL RÁPIDO
            </button>
            <button
              onClick={() => {
                if (!generating) {
                  setEngine("ai");
                  setError("");
                }
              }}
              className={`px-2 py-2 font-display text-[9px] tracking-widest transition ${engine === "ai" ? "bg-violet-400/20 text-violet-100" : "text-cyan-300/45"}`}
            >
              IA ALTA CALIDAD
            </button>
          </div>

          {engine === "ai" && (
            <div className="mt-3 border border-violet-400/20 bg-violet-500/5 p-3 anim-rise">
              <label htmlFor="pollinations-key" className="font-mono-tech text-[10px] tracking-widest text-violet-200/80">
                CLAVE GEMINI / PROVEEDOR (COMPARTIDA CON PERFIL)
              </label>
              <input
                id="pollinations-key"
                type="password"
                value={apiKey}
                onChange={(event) => setApiKey(event.target.value)}
                disabled={generating}
                placeholder="sk_..."
                autoComplete="off"
                className="mt-1.5 w-full border border-violet-400/25 bg-[#080b19] px-3 py-2 text-sm text-violet-50 outline-none placeholder:text-violet-300/25 focus:border-violet-300"
              />
              <p className="mt-2 text-[10px] leading-relaxed text-violet-200/45">
                Necesaria para modelos generativos reales. Solo permanece en memoria mientras esta pantalla está abierta y se envía directamente a Pollinations. Use una clave con presupuesto limitado.
              </p>
              <a
                href="https://enter.pollinations.ai/keys"
                target="_blank"
                rel="noreferrer"
                className="mt-1.5 inline-block font-mono-tech text-[10px] tracking-wider text-violet-200 underline underline-offset-4"
              >
                OBTENER CLAVE DEL PROVEEDOR
              </a>
            </div>
          )}

          <label htmlFor="creative-prompt" className="font-display text-[10px] tracking-[0.18em] text-cyan-200">
            DESCRIPCIÓN CREATIVA
          </label>
          <textarea
            id="creative-prompt"
            value={prompt}
            onChange={(event) => setPrompt(event.target.value)}
            disabled={generating}
            rows={5}
            placeholder="Ejemplo: una ciudad futurista bajo una tormenta, luces azules, vista cinematográfica..."
            className="mt-2 resize-none border border-cyan-400/25 bg-[#061020]/80 p-3 text-sm leading-relaxed text-cyan-50 outline-none placeholder:text-cyan-300/25 focus:border-cyan-300 disabled:opacity-50"
          />

          <label htmlFor="creative-style" className="mt-5 font-display text-[10px] tracking-[0.18em] text-cyan-200">
            DIRECCIÓN VISUAL
          </label>
          <select
            id="creative-style"
            value={style}
            onChange={(event) => setStyle(event.target.value)}
            disabled={generating}
            className="mt-2 border border-cyan-400/25 bg-[#061020] px-3 py-2.5 text-sm text-cyan-50 outline-none focus:border-cyan-300"
          >
            <option value="cinematic">Cinematográfico</option>
            <option value="cosmic">Cósmico</option>
            <option value="noir">Futurismo noir</option>
            <option value="clean">Tecnología limpia</option>
          </select>

          <div className="mt-4 flex items-center justify-between gap-2">
            <span className="font-display text-[10px] tracking-[0.18em] text-cyan-200">FORMATO</span>
            <div className="flex border border-cyan-400/20 p-0.5">
              {(["16:9", "1:1", "9:16"] as AspectRatio[]).map((ratio) => (
                <button
                  key={ratio}
                  onClick={() => {
                    if (!generating) {
                      setAspect(ratio);
                      clearResult();
                    }
                  }}
                  className={`px-2 py-1 font-mono-tech text-[10px] transition ${aspect === ratio ? "bg-cyan-400/20 text-cyan-100" : "text-cyan-300/40"}`}
                >
                  {ratio}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between gap-3 border border-cyan-400/15 px-3 py-2">
            <div className="min-w-0">
              <div className="font-mono-tech text-[9px] tracking-widest text-cyan-400/50">SEMILLA / VARIANTE</div>
              <div className="truncate font-mono-tech text-xs text-cyan-100/80">{seed}</div>
            </div>
            <button
              onClick={() => {
                setSeed(Math.floor(Math.random() * 2_000_000_000));
                clearResult();
              }}
              disabled={generating}
              className="btn-hud hud-clip shrink-0 px-3 py-1.5 font-display text-[9px] tracking-widest disabled:opacity-40"
            >
              NUEVA
            </button>
          </div>

          <div className="mt-5 border-y border-cyan-400/15 py-3 font-mono-tech text-[10px] leading-relaxed tracking-wider text-cyan-300/50">
            <div className="flex justify-between"><span>MOTOR</span><span className="text-cyan-200">{engine === "ai" ? "MODELO GENERATIVO IA" : "PROCEDURAL LOCAL"}</span></div>
            <div className="flex justify-between"><span>ACABADO</span><span className="text-cyan-200">{mode === "image" ? "4K SIN PÉRDIDAS" : "MOVIMIENTO 30 FPS"}</span></div>
            <div className="flex justify-between"><span>FORMATO</span><span className="text-cyan-200">{mode === "image" ? "PNG" : engine === "ai" ? "MP4 / WEBM" : "WEBM"}</span></div>
          </div>

          {error && (
            <div className="mt-3 border border-red-400/30 bg-red-500/10 p-3 text-xs leading-relaxed text-red-100 anim-rise">
              {error}
              <button
                onClick={() => {
                  setEngine("local");
                  setError("");
                  setStatus("MOTOR LOCAL PREPARADO");
                }}
                className="mt-2 block font-display text-[9px] tracking-widest text-cyan-200 underline underline-offset-4"
              >
                USAR MOTOR LOCAL
              </button>
            </div>
          )}

          <div className="mt-auto pt-5">
            {resultUrl && resultType === mode && (
              <a
                href={resultUrl}
                download={mode === "image" ? "jarvis-studio-4k.png" : `jarvis-studio-video.${extensionForMime(resultMime)}`}
                className="mb-2 flex w-full items-center justify-center border border-emerald-300/40 bg-emerald-400/10 px-4 py-3 font-display text-xs font-bold tracking-widest text-emerald-100 transition hover:bg-emerald-400/20"
              >
                DESCARGAR {mode === "image" ? "PNG 4K" : "VÍDEO"}
              </a>
            )}
            <button
              onClick={generate}
              disabled={generating || !prompt.trim() || (engine === "ai" && !apiKey.trim())}
              className="btn-hud hud-clip w-full px-5 py-3.5 font-display text-xs font-bold tracking-[0.2em] disabled:cursor-not-allowed disabled:opacity-35"
            >
              {generating
                ? `CREANDO ${progress}%`
                : engine === "ai"
                  ? mode === "image"
                    ? "GENERAR CON IA + 4K"
                    : "GENERAR VÍDEO CON IA"
                  : mode === "image"
                    ? "GENERAR IMAGEN 4K"
                    : "GENERAR VÍDEO"}
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}