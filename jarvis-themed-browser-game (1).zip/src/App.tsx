import { useEffect, useRef, useState } from "react";
import Background from "./jarvis/Background";
import Assistant from "./jarvis/Assistant";
import ArcReactor from "./jarvis/ArcReactor";
import DefenseGame from "./game/DefenseGame";
import CreatorStudio, { type StudioMode } from "./studio/CreatorStudio";

type View = "boot" | "assistant" | "game" | "studio";

const BOOT_LINES = [
  "INICIANDO NÚCLEO J.A.R.V.I.S...",
  "CALIBRANDO REACTOR ARC...",
  "CARGANDO SISTEMA CREATIVO 4K...",
  "SINCRONIZANDO SENSORES...",
  "TODOS LOS SISTEMAS PREPARADOS.",
];

export default function App() {
  const [view, setView] = useState<View>("boot");
  const [bootStep, setBootStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [studioMode, setStudioMode] = useState<StudioMode>("image");
  const [studioPrompt, setStudioPrompt] = useState("");
  const startedRef = useRef(false);

  // boot animation
  useEffect(() => {
    if (view !== "boot") return;
    const li = window.setInterval(() => {
      setBootStep((s) => Math.min(s + 1, BOOT_LINES.length));
    }, 480);
    const pi = window.setInterval(() => {
      setProgress((p) => Math.min(p + 3, 100));
    }, 70);
    return () => {
      window.clearInterval(li);
      window.clearInterval(pi);
    };
  }, [view]);

  return (
    <div className="scanlines relative h-[100dvh] w-full overflow-hidden">
      <Background />
      <div className="scanline-beam" />

      {view === "boot" && (
        <div className="relative z-10 flex h-full w-full flex-col items-center justify-center px-6">
          <div className="anim-flicker">
            <ArcReactor size={190} state="thinking" />
          </div>
          <h1 className="mt-6 font-display text-4xl font-black tracking-[0.5em] text-cyan-200 text-glow sm:text-6xl">
            J.A.R.V.I.S.
          </h1>
          <p className="mt-2 font-mono-tech text-xs tracking-[0.3em] text-cyan-400/60">
            JUST A RATHER VERY INTELLIGENT SYSTEM
          </p>

          <div className="mt-8 h-40 w-full max-w-md font-mono-tech text-xs text-cyan-300/70">
            {BOOT_LINES.slice(0, bootStep).map((l, i) => (
              <div key={i} className="anim-rise flex items-center gap-2">
                <span className="text-green-400">✓</span> {l}
              </div>
            ))}
          </div>

          <div className="mt-2 h-1.5 w-full max-w-md overflow-hidden rounded-full bg-cyan-950">
            <div
              className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-100"
              style={{ width: `${progress}%`, boxShadow: "0 0 12px #35e0ff" }}
            />
          </div>

          <button
            onClick={() => {
              startedRef.current = true;
              setView("assistant");
            }}
            disabled={progress < 100}
            className="btn-hud hud-clip mt-8 px-10 py-3 font-display text-lg font-bold tracking-widest disabled:cursor-not-allowed disabled:opacity-30"
          >
            {progress < 100 ? "PREPARANDO..." : "EMPEZAR"}
          </button>
        </div>
      )}

      {view === "assistant" && (
        <Assistant
          onLaunchGame={() => setView("game")}
          onLaunchStudio={(mode, prompt) => {
            setStudioMode(mode);
            setStudioPrompt(prompt);
            setView("studio");
          }}
        />
      )}

      {view === "game" && (
        <div className="relative z-10 h-full w-full">
          <DefenseGame onExit={() => setView("assistant")} />
        </div>
      )}

      {view === "studio" && (
        <div className="relative z-10 h-full w-full">
          <CreatorStudio initialMode={studioMode} initialPrompt={studioPrompt} onExit={() => setView("assistant")} />
        </div>
      )}
    </div>
  );
}
