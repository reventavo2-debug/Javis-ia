import { useCallback, useEffect, useRef, useState } from "react";

interface SRResult {
  transcript: string;
}
interface SRResultGroup extends ArrayLike<SRResult> {
  isFinal: boolean;
}
interface SREvent {
  results: ArrayLike<SRResultGroup>;
  resultIndex: number;
}
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((e: SREvent) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: unknown) => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

export interface VoiceOption {
  id: string;
  name: string;
  lang: string;
  quality: "NATURAL" | "SISTEMA";
  recommended: boolean;
}

export interface LanguageOption {
  id: string;
  label: string;
  voices: number;
}

export type VoiceStyle = "cinematic" | "natural" | "deep";

const VOICE_KEY = "jarvis_preferred_voice";
const LANGUAGE_KEY = "jarvis_preferred_language";
const CONTINUOUS_KEY = "jarvis_continuous_conversation";
const VOICE_STYLE_KEY = "jarvis_voice_style";
const NATURAL_VOICE = /natural|neural|premium|enhanced|online|studio|wavenet/i;
const MASCULINE_VOICE = /alvaro|álvaro|jorge|diego|carlos|enrique|pablo|raul|raúl|dario|darío|javier|daniel|david|mark|thomas|arthur|ryan|george|oliver|conrad|killian|stefan|dmitry|maxim|pavel|yunxi|yunyang|kangkang|cosimo|henri|claude|paul|male|hombre/i;

const REQUIRED_LANGUAGES = [
  { id: "es-ES", label: "Español", preferred: /google\s*espa[nñ]ol|google\s*spanish|alvaro|álvaro|jorge|diego|carlos|enrique|pablo/i },
  { id: "en-GB", label: "English (UK)", preferred: /ryan|daniel|arthur|george|oliver|uk english male|british/i },
  { id: "de-DE", label: "Deutsch", preferred: /conrad|killian|stefan|male/i },
  { id: "ru-RU", label: "Русский", preferred: /dmitry|maxim|pavel|male/i },
  { id: "zh-CN", label: "中文", preferred: /yunxi|yunyang|kangkang|xiaoxiao|male/i },
  { id: "it-IT", label: "Italiano", preferred: /diego|cosimo|male/i },
  { id: "fr-FR", label: "Français", preferred: /henri|claude|paul|male/i },
] as const;

function getRecognitionCtor(): (new () => SpeechRecognitionLike) | null {
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

function voiceId(voice: SpeechSynthesisVoice) {
  return `${voice.voiceURI}::${voice.lang}`;
}

function voiceScore(voice: SpeechSynthesisVoice, language: string) {
  const lang = voice.lang.toLowerCase();
  const name = voice.name.toLowerCase();
  const profile = REQUIRED_LANGUAGES.find((item) => item.id.toLowerCase() === language.toLowerCase());
  let score = 0;
  if (lang === language.toLowerCase()) score += 220;
  else if (lang.split("-")[0] === language.toLowerCase().split("-")[0]) score += 90;
  if (language.toLowerCase() === "es-es" && /google\s*espa[nñ]ol|google\s*spanish/.test(name)) score += 140;
  if (NATURAL_VOICE.test(voice.name)) score += 85;
  if (!voice.localService) score += 25;
  if (profile?.preferred.test(voice.name)) score += 70;
  else if (MASCULINE_VOICE.test(voice.name)) score += 35;
  if (voice.default) score += 5;
  return score;
}

function sameLanguage(a: string, b: string) {
  return a.toLowerCase().replace("_", "-") === b.toLowerCase().replace("_", "-");
}

function previewForLanguage(language: string) {
  const base = language.toLowerCase().split("-")[0];
  const samples: Record<string, string> = {
    es: "Sistemas en línea. Voz calibrada y lista para asistirle, señor.",
    en: "Systems online. Voice calibrated and ready to assist you, sir.",
    fr: "Systèmes en ligne. Voix calibrée et prête à vous assister, monsieur.",
    de: "Systeme online. Stimme kalibriert und bereit, Ihnen zu helfen.",
    it: "Sistemi in linea. Voce calibrata e pronta ad assisterla, signore.",
    ru: "Системы включены. Голос настроен и готов помочь вам, сэр.",
    zh: "系统已上线。语音校准完毕，随时为您服务。",
  };
  return samples[base] ?? "Systems online. Voice calibration complete.";
}

function prepareForSpeech(text: string, language: string) {
  let prepared = text
    .replace(/\.{2,}/g, ", ")
    .replace(/[;:]+/g, ",")
    .replace(/\s+/g, " ")
    .trim();
  if (language.toLowerCase().startsWith("es")) {
    prepared = prepared
      .replace(/J\.?A\.?R\.?V\.?I\.?S\.?/gi, "Yárvis")
      .replace(/\bARC\b/gi, "arc")
      .replace(/\bIA\b/g, "inteligencia artificial");
  }
  return prepared;
}

function splitIntoPhrases(text: string, language: string) {
  const prepared = prepareForSpeech(text, language);
  if (prepared.length <= 360) return [prepared];

  const sentences = prepared.match(/[^.!?]+[.!?]?/g) ?? [prepared];
  const chunks: string[] = [];
  let current = "";
  for (const sentence of sentences) {
    const clean = sentence.trim();
    if (!clean) continue;
    if (current && `${current} ${clean}`.length > 260) {
      chunks.push(current);
      current = clean;
    } else {
      current = current ? `${current} ${clean}` : clean;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

export function useSpeech(onTranscript: (text: string) => void) {
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [supported, setSupported] = useState(true);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [interimTranscript, setInterimTranscript] = useState("");
  const [continuousConversation, setContinuousConversation] = useState(
    () => localStorage.getItem(CONTINUOUS_KEY) !== "false",
  );
  const [voiceStyle, setVoiceStyleState] = useState<VoiceStyle>(
    () => (localStorage.getItem(VOICE_STYLE_KEY) as VoiceStyle | null) || "cinematic",
  );
  const [voiceOptions, setVoiceOptions] = useState<VoiceOption[]>([]);
  const [languageOptions, setLanguageOptions] = useState<LanguageOption[]>(
    REQUIRED_LANGUAGES.map((language) => ({ id: language.id, label: language.label, voices: 0 })),
  );
  const [selectedLanguage, setSelectedLanguage] = useState(() => {
    const saved = localStorage.getItem(LANGUAGE_KEY);
    return REQUIRED_LANGUAGES.some((language) => language.id === saved) ? saved! : "es-ES";
  });
  const [selectedVoiceId, setSelectedVoiceId] = useState("");
  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const voiceRef = useRef<SpeechSynthesisVoice | null>(null);
  const allVoicesRef = useRef<SpeechSynthesisVoice[]>([]);
  const selectedLanguageRef = useRef(selectedLanguage);
  const continuousRef = useRef(continuousConversation);
  const keepListeningRef = useRef(false);
  const recognitionActiveRef = useRef(false);
  const recognitionSuspendedRef = useRef(false);
  const restartTimerRef = useRef<number | null>(null);
  const speechRunRef = useRef(0);
  const pauseTimerRef = useRef<number | null>(null);
  const cbRef = useRef(onTranscript);
  cbRef.current = onTranscript;

  const beginRecognition = useCallback(() => {
    const rec = recRef.current;
    if (!rec || recognitionActiveRef.current || recognitionSuspendedRef.current) return;
    try {
      rec.lang = selectedLanguageRef.current;
      rec.continuous = continuousRef.current;
      rec.start();
      recognitionActiveRef.current = true;
      setListening(true);
    } catch {
      recognitionActiveRef.current = false;
      setListening(false);
    }
  }, []);

  const useVoicesForLanguage = useCallback((available: SpeechSynthesisVoice[], language: string, preferredId?: string | null) => {
    const base = language.toLowerCase().split("-")[0];
    const candidates = available
      .filter((voice) => voice.lang.toLowerCase().split("-")[0] === base)
      .sort((a, b) => voiceScore(b, language) - voiceScore(a, language));
    const selected = candidates.find((voice) => voiceId(voice) === preferredId) ?? candidates[0] ?? null;

    voiceRef.current = selected;
    setSelectedVoiceId(selected ? voiceId(selected) : "");
    if (selected) localStorage.setItem(`${VOICE_KEY}:${language}`, voiceId(selected));
    setVoiceOptions(
      candidates.map((voice, index) => ({
        id: voiceId(voice),
        name: voice.name,
        lang: voice.lang,
        quality: NATURAL_VOICE.test(voice.name) || !voice.localService ? "NATURAL" : "SISTEMA",
        recommended: index === 0,
      })),
    );
  }, []);

  useEffect(() => {
    const Ctor = getRecognitionCtor();
    if (!Ctor) {
      setSupported(false);
      return;
    }
    const rec = new Ctor();
    rec.lang = selectedLanguageRef.current;
    rec.continuous = continuousRef.current;
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    rec.onresult = (e) => {
      let finalText = "";
      let interimText = "";
      for (let index = e.resultIndex; index < e.results.length; index++) {
        const result = e.results[index];
        const text = result?.[0]?.transcript ?? "";
        if (result.isFinal) finalText += text;
        else interimText += text;
      }
      setInterimTranscript(interimText.trim());
      if (finalText.trim()) {
        setInterimTranscript("");
        cbRef.current(finalText.trim());
      }
    };
    rec.onend = () => {
      recognitionActiveRef.current = false;
      setListening(false);
      if (keepListeningRef.current && continuousRef.current && !recognitionSuspendedRef.current) {
        restartTimerRef.current = window.setTimeout(beginRecognition, 280);
      }
    };
    rec.onerror = () => {
      recognitionActiveRef.current = false;
      setListening(false);
    };
    recRef.current = rec;
    return () => {
      try {
        if (restartTimerRef.current !== null) window.clearTimeout(restartTimerRef.current);
        rec.abort();
      } catch {
        // Some engines throw when recognition has not started.
      }
    };
  }, [beginRecognition]);

  useEffect(() => {
    if (!("speechSynthesis" in window)) return;

    const loadVoices = () => {
      const available = window.speechSynthesis.getVoices();
      if (!available.length) return;
      allVoicesRef.current = available;

      const languages = REQUIRED_LANGUAGES.map((language) => ({
        id: language.id,
        label: language.label,
        voices: available.filter(
          (voice) => voice.lang.toLowerCase().split("-")[0] === language.id.toLowerCase().split("-")[0],
        ).length,
      }));
      setLanguageOptions(languages);

      const requested = selectedLanguageRef.current;
      const language = languages.some((item) => sameLanguage(item.id, requested)) ? requested : "es-ES";
      selectedLanguageRef.current = language;
      setSelectedLanguage(language);
      if (recRef.current) recRef.current.lang = language;
      useVoicesForLanguage(available, language, localStorage.getItem(`${VOICE_KEY}:${language}`));
    };

    loadVoices();
    window.speechSynthesis.addEventListener("voiceschanged", loadVoices);
    return () => window.speechSynthesis.removeEventListener("voiceschanged", loadVoices);
  }, [useVoicesForLanguage]);

  const cancelSpeech = useCallback(() => {
    speechRunRef.current += 1;
    if (pauseTimerRef.current !== null) window.clearTimeout(pauseTimerRef.current);
    pauseTimerRef.current = null;
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }, []);

  const startListening = useCallback(() => {
    if (!recRef.current || listening) return;
    cancelSpeech();
    recognitionSuspendedRef.current = false;
    keepListeningRef.current = true;
    beginRecognition();
  }, [beginRecognition, cancelSpeech, listening]);

  const stopListening = useCallback(() => {
    keepListeningRef.current = false;
    recognitionSuspendedRef.current = false;
    if (restartTimerRef.current !== null) window.clearTimeout(restartTimerRef.current);
    restartTimerRef.current = null;
    try {
      recRef.current?.stop();
    } catch {
      // Recognition may already have stopped itself.
    }
    recognitionActiveRef.current = false;
    setInterimTranscript("");
    setListening(false);
  }, []);

  const speak = useCallback(
    (text: string) => {
      if (!voiceEnabled || !("speechSynthesis" in window)) return;

      cancelSpeech();
      recognitionSuspendedRef.current = true;
      if (recognitionActiveRef.current) {
        try {
          recRef.current?.stop();
        } catch {
          // Recognition may already be ending.
        }
      }
      const runId = speechRunRef.current;
      const phrases = splitIntoPhrases(text, selectedLanguageRef.current);
      if (!phrases.length) return;

      const resumeConversation = () => {
        recognitionSuspendedRef.current = false;
        if (keepListeningRef.current && continuousRef.current) {
          restartTimerRef.current = window.setTimeout(beginRecognition, 160);
        }
      };

      const playPhrase = (index: number) => {
        if (speechRunRef.current !== runId || index >= phrases.length) {
          if (speechRunRef.current === runId) setSpeaking(false);
          return;
        }

        const utterance = new SpeechSynthesisUtterance(phrases[index]);
        const selected = voiceRef.current;
        utterance.lang = selected?.lang || selectedLanguageRef.current;
        const profile = {
          cinematic: { rate: 1, pitch: 0.93 },
          natural: { rate: 1.05, pitch: 0.98 },
          deep: { rate: 0.96, pitch: 0.84 },
        }[voiceStyle];
        utterance.rate = profile.rate;
        utterance.pitch = profile.pitch;
        utterance.volume = 1;
        if (selected) utterance.voice = selected;

        utterance.onstart = () => {
          if (speechRunRef.current === runId) setSpeaking(true);
        };
        utterance.onend = () => {
          if (speechRunRef.current !== runId) return;
          if (index === phrases.length - 1) {
            setSpeaking(false);
            resumeConversation();
            return;
          }
          pauseTimerRef.current = window.setTimeout(() => playPhrase(index + 1), 10);
        };
        utterance.onerror = () => {
          if (speechRunRef.current === runId) {
            setSpeaking(false);
            resumeConversation();
          }
        };
        window.speechSynthesis.speak(utterance);
      };

      playPhrase(0);
    },
    [beginRecognition, cancelSpeech, voiceEnabled, voiceStyle],
  );

  const selectVoice = useCallback((id: string) => {
    const voice = allVoicesRef.current.find((item) => voiceId(item) === id);
    if (!voice) return;
    voiceRef.current = voice;
    setSelectedVoiceId(id);
    localStorage.setItem(`${VOICE_KEY}:${selectedLanguageRef.current}`, id);
  }, []);

  const selectLanguage = useCallback(
    (language: string) => {
      cancelSpeech();
      recognitionSuspendedRef.current = false;
      selectedLanguageRef.current = language;
      setSelectedLanguage(language);
      localStorage.setItem(LANGUAGE_KEY, language);
      if (recRef.current) {
        recRef.current.lang = language;
        if (recognitionActiveRef.current) {
          try {
            recRef.current.stop();
          } catch {
            // The next recognition cycle will use the new language.
          }
        }
      }
      useVoicesForLanguage(allVoicesRef.current, language);
    },
    [cancelSpeech, useVoicesForLanguage],
  );

  const toggleContinuousConversation = useCallback(() => {
    setContinuousConversation((enabled) => {
      const next = !enabled;
      continuousRef.current = next;
      localStorage.setItem(CONTINUOUS_KEY, String(next));
      if (recRef.current) recRef.current.continuous = next;
      return next;
    });
  }, []);

  const setVoiceStyle = useCallback((style: VoiceStyle) => {
    setVoiceStyleState(style);
    localStorage.setItem(VOICE_STYLE_KEY, style);
  }, []);

  const previewVoice = useCallback(() => {
    speak(previewForLanguage(selectedLanguage));
  }, [selectedLanguage, speak]);

  const toggleVoice = useCallback(() => {
    setVoiceEnabled((enabled) => {
      if (enabled) {
        cancelSpeech();
        recognitionSuspendedRef.current = false;
        if (keepListeningRef.current && continuousRef.current) {
          restartTimerRef.current = window.setTimeout(beginRecognition, 180);
        }
      }
      return !enabled;
    });
  }, [beginRecognition, cancelSpeech]);

  useEffect(() => cancelSpeech, [cancelSpeech]);

  return {
    listening,
    speaking,
    supported,
    voiceEnabled,
    interimTranscript,
    continuousConversation,
    voiceStyle,
    voiceOptions,
    languageOptions,
    selectedLanguage,
    selectedVoiceId,
    startListening,
    stopListening,
    speak,
    stopSpeaking: cancelSpeech,
    toggleVoice,
    toggleContinuousConversation,
    setVoiceStyle,
    selectLanguage,
    selectVoice,
    previewVoice,
  };
}