import { useCallback, useEffect, useRef, useState } from "react";

const CREDITS_KEY = "jarvis_credits";
const REFILL_KEY = "jarvis_last_refill";
const GRANT_KEY = "jarvis_grant_total";
const SYNC_EVENT = "jarvis-credits-changed";

export const MAX_CREDITS = 100;
export const START_CREDITS = 100;
export const DAILY_BONUS = 30;
export const COST_PER_MESSAGE = 1;

/** Timestamp of the most recent 21:00 boundary before `now`. */
export function lastRefillBoundary(now = Date.now()) {
  const date = new Date(now);
  date.setHours(21, 0, 0, 0);
  if (date.getTime() > now) date.setDate(date.getDate() - 1);
  return date.getTime();
}

/** Timestamp of the upcoming 21:00 recharge. */
export function nextRefillAt(now = Date.now()) {
  const date = new Date(now);
  date.setHours(21, 0, 0, 0);
  if (date.getTime() <= now) date.setDate(date.getDate() + 1);
  return date.getTime();
}

/** Whole calendar days between two 21:00 boundaries. */
function dayGap(from: number, to: number) {
  const start = new Date(from);
  const end = new Date(to);
  const days = Math.round((end.setHours(0, 0, 0, 0) - start.setHours(0, 0, 0, 0)) / 86_400_000);
  return Number.isFinite(days) ? days : 0;
}

function readStoredCredits() {
  const stored = Number(localStorage.getItem(CREDITS_KEY));
  if (!Number.isFinite(stored) || stored < 0) return START_CREDITS;
  return Math.min(stored, MAX_CREDITS);
}

export interface CreditsApi {
  credits: number;
  granted: number;
  bonusJustAdded: number;
  nextRefill: number;
  clearBonusFlash: () => void;
  spend: (amount?: number) => void;
  refund: (amount?: number) => void;
}

export function useCredits(): CreditsApi {
  const [credits, setCredits] = useState(readStoredCredits);
  const [granted, setGranted] = useState(() => Number(localStorage.getItem(GRANT_KEY)) || START_CREDITS);
  const [bonusJustAdded, setBonusJustAdded] = useState(0);
  const [nextRefill, setNextRefill] = useState(() => nextRefillAt());
  const bootedRef = useRef(false);

  const syncRefill = useCallback(() => {
    const now = Date.now();
    setNextRefill(nextRefillAt(now));

    const boundary = lastRefillBoundary(now);
    const seen = Number(localStorage.getItem(REFILL_KEY)) || 0;
    if (boundary <= seen) return;

    // One bonus per missed 21:00 (up to 3 days of absence), never more than once per real day.
    const missedDays = seen ? Math.min(3, Math.max(1, dayGap(seen, boundary))) : 0;
    if (!missedDays) return;
    const bonus = missedDays * DAILY_BONUS;
    localStorage.setItem(REFILL_KEY, String(boundary));

    setCredits((current) => {
      const total = Math.min(MAX_CREDITS, current + bonus);
      localStorage.setItem(CREDITS_KEY, String(total));
      window.dispatchEvent(new Event(SYNC_EVENT));
      return total;
    });
    setGranted((total) => {
      const next = total + bonus;
      localStorage.setItem(GRANT_KEY, String(next));
      return next;
    });
    setBonusJustAdded(bonus);
  }, []);

  useEffect(() => {
    if (!bootedRef.current) {
      bootedRef.current = true;
      if (localStorage.getItem(CREDITS_KEY) === null) {
        localStorage.setItem(CREDITS_KEY, String(START_CREDITS));
        localStorage.setItem(GRANT_KEY, String(START_CREDITS));
      }
      if (localStorage.getItem(REFILL_KEY) === null) {
        // First run: seed the boundary so no bonus is granted immediately.
        localStorage.setItem(REFILL_KEY, String(lastRefillBoundary()));
      }
    }
    syncRefill();
    const timer = window.setInterval(syncRefill, 5000);
    const onVisible = () => {
      if (document.visibilityState === "visible") syncRefill();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [syncRefill]);

  const spend = useCallback((amount = COST_PER_MESSAGE) => {
    setCredits((current) => {
      const next = Math.max(0, current - amount);
      localStorage.setItem(CREDITS_KEY, String(next));
      window.dispatchEvent(new Event(SYNC_EVENT));
      return next;
    });
  }, []);

  const refund = useCallback((amount = COST_PER_MESSAGE) => {
    setCredits((current) => {
      const next = Math.min(MAX_CREDITS, current + amount);
      localStorage.setItem(CREDITS_KEY, String(next));
      window.dispatchEvent(new Event(SYNC_EVENT));
      return next;
    });
  }, []);

  // Keep every mounted meter (chat header, studio header, profile panel) in sync.
  useEffect(() => {
    const sync = () => {
      setCredits(readStoredCredits());
      setGranted(Number(localStorage.getItem(GRANT_KEY)) || START_CREDITS);
    };
    window.addEventListener(SYNC_EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(SYNC_EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const clearBonusFlash = useCallback(() => setBonusJustAdded(0), []);

  // The "+30" badge fades on its own, whether or not the profile panel is open.
  useEffect(() => {
    if (!bonusJustAdded) return;
    const timer = window.setTimeout(() => setBonusJustAdded(0), 6000);
    return () => window.clearTimeout(timer);
  }, [bonusJustAdded]);

  return { credits, granted, bonusJustAdded, nextRefill, clearBonusFlash, spend, refund };
}
